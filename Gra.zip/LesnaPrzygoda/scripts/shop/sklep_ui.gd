extends Control
## Okno sklepu: zakładki SIEKIERY i ŚWIATY. Zakup naprawdę odejmuje monety.

const Ikona := preload("res://scripts/ui/ikona_kontrolka.gd")

signal zamkniety

var _zakladka := 0
var _lista: VBoxContainer
var _przewijanie: ScrollContainer
var _etykieta_monet: Label
var _przyciski_zakladek: Array = []

func _ready() -> void:
	visible = false
	mouse_filter = Control.MOUSE_FILTER_STOP
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var tlo := ColorRect.new()
	tlo.color = Color(0, 0, 0, 0.65)
	add_child(tlo)
	tlo.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", _styl(Color(0.16, 0.11, 0.07, 0.98), 18))
	add_child(panel)
	panel.anchor_left = 0.07
	panel.anchor_top = 0.05
	panel.anchor_right = 0.93
	panel.anchor_bottom = 0.95
	panel.offset_left = 0.0
	panel.offset_top = 0.0
	panel.offset_right = 0.0
	panel.offset_bottom = 0.0

	var margines := MarginContainer.new()
	for strona in ["margin_left", "margin_right", "margin_top", "margin_bottom"]:
		margines.add_theme_constant_override(strona, 16)
	panel.add_child(margines)

	var kolumna := VBoxContainer.new()
	kolumna.add_theme_constant_override("separation", 10)
	margines.add_child(kolumna)

	# nagłówek: ikona + tytuł + monety + przycisk zamknięcia
	var naglowek := HBoxContainer.new()
	naglowek.add_theme_constant_override("separation", 12)
	kolumna.add_child(naglowek)
	var ik := Ikona.new()
	ik.rodzaj = "sklep"
	ik.custom_minimum_size = Vector2(56, 56)
	naglowek.add_child(ik)
	var tytul := Label.new()
	tytul.text = "SKLEP"
	tytul.add_theme_font_size_override("font_size", 38)
	tytul.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	naglowek.add_child(tytul)
	var moneta := Ikona.new()
	moneta.rodzaj = "moneta"
	moneta.custom_minimum_size = Vector2(44, 44)
	naglowek.add_child(moneta)
	_etykieta_monet = Label.new()
	_etykieta_monet.add_theme_font_size_override("font_size", 32)
	_etykieta_monet.add_theme_color_override("font_color", Color(1, 0.85, 0.3))
	naglowek.add_child(_etykieta_monet)
	var zamknij := Button.new()
	zamknij.text = "X"
	zamknij.custom_minimum_size = Vector2(70, 56)
	zamknij.add_theme_font_size_override("font_size", 30)
	zamknij.pressed.connect(zamknij_okno)
	naglowek.add_child(zamknij)

	# zakładki
	var zakladki := HBoxContainer.new()
	zakladki.add_theme_constant_override("separation", 10)
	kolumna.add_child(zakladki)
	var nazwy := ["SIEKIERY", "ŚWIATY"]
	for i in nazwy.size():
		var b := Button.new()
		b.text = nazwy[i]
		b.custom_minimum_size = Vector2(0, 58)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.add_theme_font_size_override("font_size", 28)
		b.pressed.connect(_wybierz_zakladke.bind(i))
		zakladki.add_child(b)
		_przyciski_zakladek.append(b)

	# lista przewijana + duże przyciski GÓRA / DÓŁ obok niej
	var srodek := HBoxContainer.new()
	srodek.size_flags_vertical = Control.SIZE_EXPAND_FILL
	srodek.add_theme_constant_override("separation", 8)
	kolumna.add_child(srodek)

	_przewijanie = ScrollContainer.new()
	_przewijanie.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_przewijanie.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	srodek.add_child(_przewijanie)
	# gruby pasek przewijania, łatwy do złapania palcem
	_przewijanie.get_v_scroll_bar().custom_minimum_size = Vector2(34, 0)
	_lista = VBoxContainer.new()
	_lista.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_lista.add_theme_constant_override("separation", 10)
	_przewijanie.add_child(_lista)

	var strzalki := VBoxContainer.new()
	strzalki.add_theme_constant_override("separation", 8)
	srodek.add_child(strzalki)
	strzalki.add_child(_przycisk_przewijania("GÓRA", -1))
	strzalki.add_child(_przycisk_przewijania("DÓŁ", 1))

	Stan.zmieniono.connect(_odswiez)

func otworz() -> void:
	visible = true
	_odswiez()

func zamknij_okno() -> void:
	visible = false
	zamkniety.emit()

func _przycisk_przewijania(tekst: String, kierunek: int) -> Button:
	var b := Button.new()
	b.text = tekst
	b.custom_minimum_size = Vector2(110, 0)
	b.size_flags_vertical = Control.SIZE_EXPAND_FILL
	b.add_theme_font_size_override("font_size", 26)
	b.pressed.connect(_przewin.bind(kierunek))
	return b

## Jedno kliknięcie przewija listę o mniej więcej półtora wiersza.
func _przewin(kierunek: int) -> void:
	var cel := maxi(0, _przewijanie.scroll_vertical + kierunek * 420)
	var tw := create_tween()
	tw.tween_property(_przewijanie, "scroll_vertical", cel, 0.25)

func _wybierz_zakladke(i: int) -> void:
	_zakladka = i
	_odswiez()

func _styl(kolor: Color, zaokraglenie: int) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = kolor
	s.set_corner_radius_all(zaokraglenie)
	return s

func _odswiez() -> void:
	if not visible:
		return
	_etykieta_monet.text = str(Stan.pieniadze)
	for i in _przyciski_zakladek.size():
		_przyciski_zakladek[i].modulate = Color(1, 0.9, 0.5) if i == _zakladka else Color(0.75, 0.75, 0.75)
	for dziecko in _lista.get_children():
		dziecko.queue_free()
	if _zakladka == 0:
		_wiersze_siekier()
	else:
		_wiersze_swiatow()

func _wiersze_siekier() -> void:
	for i in Stan.SIEKIERY.size():
		var s: Dictionary = Stan.SIEKIERY[i]
		var cena: int = s["cena"]
		var posiadana: bool = Stan.posiadane_siekiery[i]
		var zalozona: bool = Stan.aktualna_siekiera == i
		var tekst := ""
		var aktywny := true
		var akcja: Callable
		if zalozona:
			tekst = "ZAŁOŻONA"
			aktywny = false
		elif posiadana:
			tekst = "ZAŁÓŻ"
			akcja = Stan.zaloz_siekiere.bind(i)
		else:
			tekst = "KUP\n%d" % cena
			aktywny = Stan.pieniadze >= cena
			akcja = Stan.kup_siekiere.bind(i)
		var statystyki := "Obrażenia: %s   |   Zamach: %s s" % [str(s["obrazenia"]), str(s["czas"])]
		_lista.add_child(_wiersz("siekiera", s["kolor"], "%d. %s" % [i + 1, s["nazwa"]],
			s["opis"], statystyki, tekst, aktywny, akcja))

func _wiersze_swiatow() -> void:
	for i in Stan.SWIATY.size():
		var s: Dictionary = Stan.SWIATY[i]
		var cena: int = s["cena"]
		var posiadany: bool = Stan.posiadane_swiaty[i]
		var tekst := "POSIADANY" if posiadany else "KUP\n%d" % cena
		var aktywny: bool = (not posiadany) and Stan.pieniadze >= cena
		var akcja: Callable = Stan.kup_swiat.bind(i)
		_lista.add_child(_wiersz("swiat", Color.WHITE, s["nazwa"], s["opis"],
			"Wejście do świata pojawi się w przyszłej aktualizacji.", tekst, aktywny, akcja))

func _wiersz(rodzaj: String, kolor: Color, nazwa: String, opis: String, statystyki: String,
		tekst_przycisku: String, aktywny: bool, akcja: Callable) -> Control:
	var karta := PanelContainer.new()
	karta.mouse_filter = Control.MOUSE_FILTER_PASS    # przeciągnięcie palcem przewija listę
	karta.add_theme_stylebox_override("panel", _styl(Color(0.26, 0.19, 0.12), 12))
	var m := MarginContainer.new()
	for strona in ["margin_left", "margin_right", "margin_top", "margin_bottom"]:
		m.add_theme_constant_override(strona, 10)
	m.mouse_filter = Control.MOUSE_FILTER_PASS
	karta.add_child(m)
	var h := HBoxContainer.new()
	h.mouse_filter = Control.MOUSE_FILTER_PASS
	h.add_theme_constant_override("separation", 14)
	m.add_child(h)

	var ik := Ikona.new()
	ik.rodzaj = rodzaj
	ik.kolor = kolor
	ik.custom_minimum_size = Vector2(90, 90)
	h.add_child(ik)

	var t := VBoxContainer.new()
	t.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	t.mouse_filter = Control.MOUSE_FILTER_PASS
	h.add_child(t)
	var l_nazwa := Label.new()
	l_nazwa.text = nazwa
	l_nazwa.add_theme_font_size_override("font_size", 28)
	t.add_child(l_nazwa)
	var l_opis := Label.new()
	l_opis.text = opis
	l_opis.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l_opis.custom_minimum_size = Vector2(220, 0)
	l_opis.add_theme_font_size_override("font_size", 20)
	l_opis.add_theme_color_override("font_color", Color(0.85, 0.8, 0.7))
	t.add_child(l_opis)
	var l_stat := Label.new()
	l_stat.text = statystyki
	l_stat.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l_stat.custom_minimum_size = Vector2(220, 0)
	l_stat.add_theme_font_size_override("font_size", 20)
	l_stat.add_theme_color_override("font_color", Color(1, 0.85, 0.3))
	t.add_child(l_stat)

	var b := Button.new()
	b.text = tekst_przycisku
	b.custom_minimum_size = Vector2(190, 80)
	b.add_theme_font_size_override("font_size", 26)
	b.disabled = not aktywny
	if akcja.is_valid():
		b.pressed.connect(akcja)
	h.add_child(b)
	return karta
