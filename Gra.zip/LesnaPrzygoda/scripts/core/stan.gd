extends Node
## Globalny stan gry (autoload "Stan"): pieniądze, ścięte drzewa, siekiery, światy.
## Każdy skrypt może się do niego odwołać przez nazwę Stan.

signal zmieniono                       ## coś się zmieniło (odśwież interfejs)
signal drzewo_sciete(nagroda: int)     ## ścięto drzewo

## 10 siekier. "obrazenia" = ile punktów życia drzewa zabiera jedno uderzenie,
## "czas" = czas jednego zamachu w sekundach (mniej = szybciej).
const SIEKIERY: Array = [
	{"nazwa": "Stara siekiera", "cena": 0, "obrazenia": 1.0, "czas": 0.90,
		"kolor": Color(0.55, 0.50, 0.45), "opis": "Zardzewiała, ale jeszcze trzyma się trzonka."},
	{"nazwa": "Zwykła siekiera", "cena": 100, "obrazenia": 1.5, "czas": 0.85,
		"kolor": Color(0.68, 0.70, 0.72), "opis": "Porządne żelazo. Dobry początek drwala."},
	{"nazwa": "Lepsza siekiera", "cena": 300, "obrazenia": 2.2, "czas": 0.80,
		"kolor": Color(0.55, 0.78, 0.95), "opis": "Wyostrzone ostrze i wygodniejszy trzonek."},
	{"nazwa": "Stalowa siekiera", "cena": 700, "obrazenia": 3.2, "czas": 0.75,
		"kolor": Color(0.82, 0.86, 0.90), "opis": "Hartowana stal, która nie tępi się tak szybko."},
	{"nazwa": "Profesjonalna siekiera", "cena": 1500, "obrazenia": 4.5, "czas": 0.70,
		"kolor": Color(0.35, 0.85, 0.50), "opis": "Narzędzie zawodowców. Zielone ostrze to znak jakości."},
	{"nazwa": "Wzmocniona siekiera", "cena": 3000, "obrazenia": 6.5, "czas": 0.65,
		"kolor": Color(0.95, 0.75, 0.25), "opis": "Podwójnie kuta, z miedzianymi okuciami."},
	{"nazwa": "Siekiera leśniczego", "cena": 5500, "obrazenia": 9.0, "czas": 0.60,
		"kolor": Color(0.95, 0.50, 0.20), "opis": "Rozgrzana w kuźni na pomarańczowo. Tnie jak masło."},
	{"nazwa": "Mistrzowska siekiera", "cena": 9000, "obrazenia": 13.0, "czas": 0.55,
		"kolor": Color(0.85, 0.30, 0.35), "opis": "Dzieło mistrza kowalskiego, równo wyważone."},
	{"nazwa": "Tytanowa siekiera", "cena": 15000, "obrazenia": 19.0, "czas": 0.50,
		"kolor": Color(0.60, 0.45, 0.95), "opis": "Lekka jak piórko, twarda jak skała."},
	{"nazwa": "Legendarna siekiera", "cena": 25000, "obrazenia": 28.0, "czas": 0.45,
		"kolor": Color(1.00, 0.88, 0.30), "opis": "Mówią, że ścina dąb jednym cięciem."},
]

## 2 światy do kupienia (na razie tylko zakup, wejście dodamy później).
const SWIATY: Array = [
	{"nazwa": "Mroczny Bór", "cena": 5000,
		"opis": "Gęsty, ciemny las pełen świerków i mgły."},
	{"nazwa": "Górska Puszcza", "cena": 20000,
		"opis": "Stoki, skały i ogromne, stare drzewa."},
]

var pieniadze := 0
var sciete_drzewa := 0
var posiadane_siekiery: Array = [true, false, false, false, false, false, false, false, false, false]
var aktualna_siekiera := 0
var posiadane_swiaty: Array = [false, false]

# ustawienia i położenie (też zapisywane)
const PLIK := "user://zapis.json"       ## user:// to folder zapisu na telefonie i komputerze
var czulosc_kamery := 2.5
var pierwsza_osoba := false
var ma_pozycje := false
var pozycja_gracza := Vector3.ZERO
var gracz: Node3D                        ## ustawia świat; potrzebne do zapisu pozycji
var _zapis_zaplanowany := false

func _ready() -> void:
	wczytaj()
	zmieniono.connect(_zaplanuj_zapis)

func siekiera() -> Dictionary:
	return SIEKIERY[aktualna_siekiera]

func obrazenia() -> float:
	return float(siekiera()["obrazenia"])

func zarejestruj_sciecie(nagroda: int) -> void:
	sciete_drzewa += 1
	pieniadze += nagroda
	drzewo_sciete.emit(nagroda)
	zmieniono.emit()

func kup_siekiere(i: int) -> bool:
	var cena: int = SIEKIERY[i]["cena"]
	if posiadane_siekiery[i] or pieniadze < cena:
		return false
	pieniadze -= cena
	posiadane_siekiery[i] = true
	aktualna_siekiera = i      # nowa siekiera od razu trafia do ręki
	zmieniono.emit()
	return true

func zaloz_siekiere(i: int) -> void:
	if posiadane_siekiery[i]:
		aktualna_siekiera = i
		zmieniono.emit()

func kup_swiat(i: int) -> bool:
	var cena: int = SWIATY[i]["cena"]
	if posiadane_swiaty[i] or pieniadze < cena:
		return false
	pieniadze -= cena
	posiadane_swiaty[i] = true
	zmieniono.emit()
	return true

## Tylko do testów na komputerze: klawisz M daje 1000 monet.
func _unhandled_input(zdarzenie: InputEvent) -> void:
	if zdarzenie is InputEventKey and zdarzenie.pressed and not zdarzenie.echo \
			and zdarzenie.keycode == KEY_M:
		pieniadze += 1000
		zmieniono.emit()

# ---------- zapis gry ----------

## Zapisujemy po każdej zmianie (z krótkim opóźnieniem) oraz przy zamknięciu lub wyjściu z gry.
func _zaplanuj_zapis() -> void:
	if _zapis_zaplanowany:
		return
	_zapis_zaplanowany = true
	get_tree().create_timer(1.5).timeout.connect(_zapisz_opoznione)

func _zapisz_opoznione() -> void:
	_zapis_zaplanowany = false
	zapisz()

func _notification(co: int) -> void:
	if co == NOTIFICATION_APPLICATION_PAUSED or co == NOTIFICATION_APPLICATION_FOCUS_OUT \
			or co == NOTIFICATION_WM_CLOSE_REQUEST:
		zapisz()

func zapisz() -> void:
	if is_instance_valid(gracz):
		pozycja_gracza = gracz.global_position
		ma_pozycje = true
	var dane := {
		"wersja": 1,
		"pieniadze": pieniadze,
		"sciete_drzewa": sciete_drzewa,
		"posiadane_siekiery": posiadane_siekiery,
		"aktualna_siekiera": aktualna_siekiera,
		"posiadane_swiaty": posiadane_swiaty,
		"czulosc_kamery": czulosc_kamery,
		"pierwsza_osoba": pierwsza_osoba,
		"ma_pozycje": ma_pozycje,
		"pozycja": [pozycja_gracza.x, pozycja_gracza.y, pozycja_gracza.z],
	}
	var plik := FileAccess.open(PLIK, FileAccess.WRITE)
	if plik == null:
		push_warning("Nie udało się zapisać gry: " + str(FileAccess.get_open_error()))
		return
	plik.store_string(JSON.stringify(dane))
	plik.close()

func ma_zapis() -> bool:
	return FileAccess.file_exists(PLIK)

func wczytaj() -> bool:
	if not FileAccess.file_exists(PLIK):
		return false
	var plik := FileAccess.open(PLIK, FileAccess.READ)
	if plik == null:
		return false
	var surowe: Variant = JSON.parse_string(plik.get_as_text())
	plik.close()
	if not (surowe is Dictionary):
		return false          # uszkodzony zapis: zaczynamy od nowa
	var d: Dictionary = surowe
	pieniadze = maxi(0, int(d.get("pieniadze", 0)))
	sciete_drzewa = maxi(0, int(d.get("sciete_drzewa", 0)))
	var siekiery: Variant = d.get("posiadane_siekiery", [])
	if siekiery is Array and siekiery.size() == SIEKIERY.size():
		for i in SIEKIERY.size():
			posiadane_siekiery[i] = bool(siekiery[i])
	posiadane_siekiery[0] = true
	var swiaty: Variant = d.get("posiadane_swiaty", [])
	if swiaty is Array and swiaty.size() == SWIATY.size():
		for i in SWIATY.size():
			posiadane_swiaty[i] = bool(swiaty[i])
	aktualna_siekiera = clampi(int(d.get("aktualna_siekiera", 0)), 0, SIEKIERY.size() - 1)
	if not posiadane_siekiery[aktualna_siekiera]:
		aktualna_siekiera = 0
	czulosc_kamery = clampf(float(d.get("czulosc_kamery", 2.5)), 0.8, 5.0)
	pierwsza_osoba = bool(d.get("pierwsza_osoba", false))
	ma_pozycje = bool(d.get("ma_pozycje", false))
	var poz: Variant = d.get("pozycja", [])
	if poz is Array and poz.size() == 3:
		pozycja_gracza = Vector3(float(poz[0]), float(poz[1]), float(poz[2]))
	else:
		ma_pozycje = false
	return true

## Zeruje postęp, zapisuje czysty stan i ładuje świat od nowa.
func nowa_gra() -> void:
	pieniadze = 0
	sciete_drzewa = 0
	for i in posiadane_siekiery.size():
		posiadane_siekiery[i] = (i == 0)
	for i in posiadane_swiaty.size():
		posiadane_swiaty[i] = false
	aktualna_siekiera = 0
	ma_pozycje = false
	gracz = null
	zapisz()
	get_tree().reload_current_scene()
