extends CharacterBody3D
## Postać gracza (drwal): ruch, skok, kamera zza prawego ramienia i animacje.
## Zamach siekierą idzie z boku, jak uderzenie kijem baseballowym.
##
## Sterowanie na komputerze:
##   W/A/S/D = ruch, Shift = bieg, Spacja = skok, F = ścinanie,
##   strzałki lub prawy przycisk myszy (przeciąganie) = obrót kamery.

signal uderzenie     ## wysyłany w chwili, gdy siekiera trafia
signal widok_zmieniony(pierwsza_osoba: bool)

const Y0 := 0.85     ## wysokość bioder: punkt, wokół którego skręca się tułów

@export var predkosc_chodu := 4.0
@export var predkosc_biegu := 7.5
@export var sila_skoku := 8.0
@export var grawitacja := 24.0
@export var czulosc_kamery := 2.5
@export var czulosc_myszy := 0.004
@export var czas_uderzenia := 0.9      ## ustawiane z aktualnej siekiery

var las                                 ## ustawia świat; służy do celowania w drzewa
var pierwsza_osoba := false
var _wezly_glowy: Array = []

var _ruch := Vector2.ZERO
var _kamera_wejscie := Vector2.ZERO
var _scina := false
var _faza_uderzenia := -1.0
var _uderzenie_wyslane := false
var _faza_kroku := 0.0
var _czas := 0.0
var _yaw := 0.0
var _pitch := -0.35
var _cel_obrotu := 0.0
var _ma_cel := false

var _pivot: Node3D
var _ramie: SpringArm3D
var _kamera: Camera3D
var _model: Node3D
var _tulow: Node3D
var _noga_l: Node3D
var _noga_p: Node3D
var _reka_l: Node3D
var _reka_p: Node3D
var _ostrze: MeshInstance3D
var _ostrze_mat: StandardMaterial3D

func _ready() -> void:
	floor_max_angle = deg_to_rad(55.0)
	floor_snap_length = 0.6
	_zbuduj_kolizje()
	_zbuduj_model()
	_zbuduj_kamere()
	Stan.zmieniono.connect(_odswiez_siekiere)
	_odswiez_siekiere()
	pierwsza_osoba = Stan.pierwsza_osoba
	_ustaw_widok()

# ---------- Budowanie postaci ----------

func _zbuduj_kolizje() -> void:
	var kolizja := CollisionShape3D.new()
	var ksztalt := CapsuleShape3D.new()
	ksztalt.radius = 0.35
	ksztalt.height = 1.8
	kolizja.shape = ksztalt
	kolizja.position.y = 0.9
	add_child(kolizja)

func _mat(kolor: Color, tekstura: Texture2D = null, uv: Vector3 = Vector3.ONE) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = kolor
	m.roughness = 0.9
	if tekstura:
		m.albedo_texture = tekstura
		m.uv1_scale = uv
	return m

func _wezel(mesh: Mesh, mat: Material, poz: Vector3, skala: Vector3) -> MeshInstance3D:
	mesh.material = mat
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.position = poz
	mi.scale = skala
	return mi

func _kapsula(r: float, h: float, mat: Material, poz: Vector3, skala: Vector3 = Vector3.ONE) -> MeshInstance3D:
	var m := CapsuleMesh.new()
	m.radius = r
	m.height = h
	m.radial_segments = 12
	m.rings = 4
	return _wezel(m, mat, poz, skala)

func _kula(r: float, mat: Material, poz: Vector3, skala: Vector3 = Vector3.ONE) -> MeshInstance3D:
	var m := SphereMesh.new()
	m.radius = r
	m.height = r * 2.0
	m.radial_segments = 12
	m.rings = 6
	return _wezel(m, mat, poz, skala)

func _walec(r: float, h: float, mat: Material, poz: Vector3, skala: Vector3 = Vector3.ONE) -> MeshInstance3D:
	var m := CylinderMesh.new()
	m.top_radius = r
	m.bottom_radius = r
	m.height = h
	m.radial_segments = 12
	m.rings = 1
	return _wezel(m, mat, poz, skala)

func _pudelko(rozmiar: Vector3, mat: Material, poz: Vector3) -> MeshInstance3D:
	var m := BoxMesh.new()
	m.size = rozmiar
	return _wezel(m, mat, poz, Vector3.ONE)

func _przegub(rodzic: Node3D, poz: Vector3) -> Node3D:
	var p := Node3D.new()
	p.position = poz
	rodzic.add_child(p)
	return p

func _glowa(wezel: Node3D) -> void:
	_tulow.add_child(wezel)
	_wezly_glowy.append(wezel)

func _zbuduj_model() -> void:
	var m_koszula := _mat(Color.WHITE, load("res://textures/koszula.png") as Texture2D, Vector3(2, 2, 1))
	var m_jeans := _mat(Color(0.2, 0.3, 0.5))
	var m_skora := _mat(Color(0.93, 0.74, 0.6))
	var m_nos := _mat(Color(0.88, 0.62, 0.5))
	var m_but := _mat(Color(0.22, 0.13, 0.07))
	var m_pas := _mat(Color(0.3, 0.18, 0.08))
	var m_klamra := _mat(Color(0.9, 0.75, 0.2))
	var m_broda := _mat(Color(0.35, 0.2, 0.1))
	var m_czapka := _mat(Color(0.12, 0.38, 0.32))
	var m_opaska := _mat(Color(0.9, 0.85, 0.7))
	var m_czarny := _mat(Color(0.05, 0.05, 0.05))
	var m_rekawica := _mat(Color(0.5, 0.32, 0.15))
	var m_trzonek := _mat(Color(0.45, 0.3, 0.15))

	_model = Node3D.new()
	_model.name = "Model"
	add_child(_model)
	_tulow = _przegub(_model, Vector3(0, Y0, 0))

	# tułów, pas i szyja
	_tulow.add_child(_kapsula(0.26, 0.82, m_koszula, Vector3(0, 1.17 - Y0, 0), Vector3(1.05, 1.0, 0.78)))
	_tulow.add_child(_walec(0.275, 0.08, m_pas, Vector3(0, 0.87 - Y0, 0), Vector3(1.04, 1.0, 0.82)))
	_tulow.add_child(_pudelko(Vector3(0.12, 0.09, 0.03), m_klamra, Vector3(0, 0.87 - Y0, -0.23)))
	_glowa(_walec(0.07, 0.14, m_skora, Vector3(0, 1.6 - Y0, 0)))
	# głowa: twarz, oczy, nos, broda
	_glowa(_kula(0.21, m_skora, Vector3(0, 1.76 - Y0, 0), Vector3(1.0, 1.1, 1.0)))
	for strona in [-1.0, 1.0]:
		_glowa(_kula(0.03, m_czarny, Vector3(strona * 0.075, 1.79 - Y0, -0.185)))
	_glowa(_kula(0.04, m_nos, Vector3(0, 1.73 - Y0, -0.215)))
	_glowa(_kula(0.17, m_broda, Vector3(0, 1.66 - Y0, -0.07), Vector3(1.0, 0.75, 0.9)))
	# czapka z pomponem
	_glowa(_kula(0.235, m_czapka, Vector3(0, 1.86 - Y0, 0), Vector3(1.0, 0.78, 1.0)))
	_glowa(_walec(0.228, 0.08, m_opaska, Vector3(0, 1.8 - Y0, 0)))
	_glowa(_kula(0.06, m_opaska, Vector3(0, 2.07 - Y0, 0)))

	# ręce: rękaw w kratę, rękawica na końcu
	_reka_l = _przegub(_tulow, Vector3(-0.36, 1.42 - Y0, 0))
	_reka_l.add_child(_kapsula(0.085, 0.62, m_koszula, Vector3(0, -0.28, 0)))
	_reka_l.add_child(_kula(0.09, m_rekawica, Vector3(0, -0.6, 0)))
	_reka_p = _przegub(_tulow, Vector3(0.36, 1.42 - Y0, 0))
	_reka_p.add_child(_kapsula(0.085, 0.62, m_koszula, Vector3(0, -0.28, 0)))
	_reka_p.add_child(_kula(0.09, m_rekawica, Vector3(0, -0.6, 0)))

	# siekiera w prawej ręce: trzonek i ostrze
	_reka_p.add_child(_pudelko(Vector3(0.07, 0.85, 0.07), m_trzonek, Vector3(0, -0.95, 0)))
	_ostrze_mat = _mat(Color(0.7, 0.72, 0.75))
	_ostrze_mat.metallic = 0.7
	_ostrze_mat.roughness = 0.35
	_ostrze = _pudelko(Vector3(0.05, 0.24, 0.34), _ostrze_mat, Vector3(0, -1.28, -0.15))
	_reka_p.add_child(_ostrze)

	# nogi i buty
	_noga_l = _przegub(_model, Vector3(-0.14, 0.85, 0))
	_noga_l.add_child(_kapsula(0.11, 0.86, m_jeans, Vector3(0, -0.4, 0)))
	_noga_l.add_child(_pudelko(Vector3(0.2, 0.14, 0.33), m_but, Vector3(0, -0.78, -0.05)))
	_noga_p = _przegub(_model, Vector3(0.14, 0.85, 0))
	_noga_p.add_child(_kapsula(0.11, 0.86, m_jeans, Vector3(0, -0.4, 0)))
	_noga_p.add_child(_pudelko(Vector3(0.2, 0.14, 0.33), m_but, Vector3(0, -0.78, -0.05)))

## Kolor i rozmiar ostrza zależą od aktualnej siekiery ze sklepu.
func _odswiez_siekiere() -> void:
	if _ostrze == null:
		return
	var s: Dictionary = Stan.siekiera()
	var idx: int = Stan.aktualna_siekiera
	_ostrze_mat.albedo_color = s["kolor"]
	_ostrze.scale = Vector3(1.0, 1.0 + 0.04 * idx, 1.0 + 0.05 * idx)
	czas_uderzenia = float(s["czas"])

func _zbuduj_kamere() -> void:
	_pivot = Node3D.new()
	_pivot.top_level = true
	add_child(_pivot)
	_pivot.global_position = global_position + Vector3(0, 1.5, 0)

	_ramie = SpringArm3D.new()
	_ramie.spring_length = 4.2
	_ramie.margin = 0.1
	_ramie.collision_mask = 1
	var kula := SphereShape3D.new()
	kula.radius = 0.25
	_ramie.shape = kula
	_pivot.add_child(_ramie)
	_ramie.add_excluded_object(get_rid())

	_kamera = Camera3D.new()
	_kamera.h_offset = 0.9      # kamera lekko z prawej strony postaci
	_kamera.fov = 70.0
	_kamera.far = 400.0
	_ramie.add_child(_kamera)
	_kamera.make_current()

# ---------- Widok: trzecia i pierwsza osoba ----------

func przelacz_widok() -> void:
	pierwsza_osoba = not pierwsza_osoba
	_ustaw_widok()
	Stan.zmieniono.emit()      # zapisze wybrany widok

func _ustaw_widok() -> void:
	for w in _wezly_glowy:
		w.visible = not pierwsza_osoba      # głowy nie widać z "oczu" postaci
	if pierwsza_osoba:
		_ramie.spring_length = 0.01
		_kamera.h_offset = 0.0
		_kamera.fov = 75.0
		_pitch = 0.0
	else:
		_ramie.spring_length = 4.2
		_kamera.h_offset = 0.9              # kamera lekko z prawej strony postaci
		_kamera.fov = 70.0
		_pitch = -0.35
	Stan.pierwsza_osoba = pierwsza_osoba
	widok_zmieniony.emit(pierwsza_osoba)

func _ogranicz_pitch(p: float) -> float:
	if pierwsza_osoba:
		return clampf(p, -1.4, 1.4)
	return clampf(p, -1.2, 0.5)

## Kierunek, w którym patrzy kamera (poziomo). Używany do celowania w pierwszej osobie.
func kierunek_patrzenia() -> Vector3:
	return Basis(Vector3.UP, _yaw) * Vector3(0, 0, -1)

# ---------- Polecenia z interfejsu ----------

func ustaw_ruch(wektor: Vector2) -> void:
	_ruch = wektor

func ustaw_kamere(wektor: Vector2) -> void:
	_kamera_wejscie = wektor

func skocz() -> void:
	if is_on_floor():
		velocity.y = sila_skoku

func scinaj(wcisniete: bool) -> void:
	_scina = wcisniete

# ---------- Wejście z klawiatury i myszy ----------

func _unhandled_input(zdarzenie: InputEvent) -> void:
	if zdarzenie is InputEventMouseMotion \
			and Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT):
		var mnoznik := Stan.czulosc_kamery / 2.5
		_yaw -= zdarzenie.relative.x * czulosc_myszy * mnoznik
		_pitch = _ogranicz_pitch(_pitch - zdarzenie.relative.y * czulosc_myszy * mnoznik)
	if zdarzenie is InputEventKey and zdarzenie.pressed and not zdarzenie.echo \
			and zdarzenie.keycode == KEY_V:
		przelacz_widok()

func _klawiatura_ruch() -> Vector2:
	var v := Vector2.ZERO
	if Input.is_key_pressed(KEY_W): v.y -= 1.0
	if Input.is_key_pressed(KEY_S): v.y += 1.0
	if Input.is_key_pressed(KEY_A): v.x -= 1.0
	if Input.is_key_pressed(KEY_D): v.x += 1.0
	return v

func _klawiatura_kamera() -> Vector2:
	var v := Vector2.ZERO
	if Input.is_key_pressed(KEY_LEFT): v.x -= 1.0
	if Input.is_key_pressed(KEY_RIGHT): v.x += 1.0
	if Input.is_key_pressed(KEY_UP): v.y -= 1.0
	if Input.is_key_pressed(KEY_DOWN): v.y += 1.0
	return v

# ---------- Fizyka i ruch ----------

func _zacznij_zamach() -> void:
	_faza_uderzenia = 0.0
	_uderzenie_wyslane = false
	_ma_cel = false
	# jeśli drzewo jest blisko, obracamy się do niego przodem
	if las and not pierwsza_osoba:
		var d = las.najblizsze_drzewo(global_position, 3.0)
		if d:
			var k: Vector3 = d.global_position - global_position
			_cel_obrotu = atan2(-k.x, -k.z)
			_ma_cel = true

func _physics_process(delta: float) -> void:
	var v := (_ruch + _klawiatura_ruch()).limit_length(1.0)
	var kierunek := Basis(Vector3.UP, _yaw) * Vector3(v.x, 0.0, v.y)

	var sila := v.length()
	var bieg := sila > 0.85 or Input.is_key_pressed(KEY_SHIFT)
	var predkosc := predkosc_biegu if bieg else predkosc_chodu * minf(sila / 0.85, 1.0)
	if _faza_uderzenia >= 0.0:
		predkosc = 0.0   # podczas zamachu postać stoi w miejscu

	var cel := kierunek.normalized() * predkosc if sila > 0.01 else Vector3.ZERO
	velocity.x = move_toward(velocity.x, cel.x, 35.0 * delta)
	velocity.z = move_toward(velocity.z, cel.z, 35.0 * delta)

	if is_on_floor():
		if Input.is_key_pressed(KEY_SPACE):
			velocity.y = sila_skoku
	else:
		velocity.y -= grawitacja * delta

	if (_scina or Input.is_key_pressed(KEY_F)) and _faza_uderzenia < 0.0 and is_on_floor():
		_zacznij_zamach()

	move_and_slide()

	if pierwsza_osoba:
		_model.rotation.y = _yaw      # w pierwszej osobie postać patrzy tam, gdzie kamera
	elif _faza_uderzenia >= 0.0:
		if _ma_cel:
			_model.rotation.y = lerp_angle(_model.rotation.y, _cel_obrotu, 1.0 - exp(-14.0 * delta))
	elif kierunek.length() > 0.1:
		var kat := atan2(-kierunek.x, -kierunek.z)
		_model.rotation.y = lerp_angle(_model.rotation.y, kat, 1.0 - exp(-12.0 * delta))

	if global_position.y < -60.0:
		global_position = Vector3(0, 30, 0)
		velocity = Vector3.ZERO

# ---------- Kamera i animacje (co klatkę) ----------

func _process(delta: float) -> void:
	_czas += delta
	var k := (_kamera_wejscie + _klawiatura_kamera()).limit_length(1.0)
	_yaw -= k.x * Stan.czulosc_kamery * delta
	_pitch = _ogranicz_pitch(_pitch - k.y * Stan.czulosc_kamery * delta)
	_pivot.rotation.y = _yaw
	_ramie.rotation.x = _pitch
	if pierwsza_osoba:
		_pivot.global_position = global_position + Vector3(0, 1.72, 0)
	else:
		var cel := global_position + Vector3(0, 1.5, 0)
		_pivot.global_position = _pivot.global_position.lerp(cel, 1.0 - exp(-14.0 * delta))
	_animuj(delta)

func _animuj(delta: float) -> void:
	var plynnosc := 1.0 - exp(-16.0 * delta)
	var poziome := Vector2(velocity.x, velocity.z).length()
	var na_ziemi := is_on_floor()
	var cel_nl := 0.0
	var cel_np := 0.0
	var cel_rl := 0.0
	var cel_rp := 0.0

	if not na_ziemi:
		cel_nl = -0.5
		cel_np = 0.4
		cel_rl = -2.4
		cel_rp = -2.4
	elif poziome > 0.3:
		_faza_kroku += poziome * delta * 1.7
		var zakres := clampf((poziome - predkosc_chodu) / (predkosc_biegu - predkosc_chodu), 0.0, 1.0)
		var amplituda := lerpf(0.6, 1.1, zakres)
		var fala := sin(_faza_kroku)
		cel_nl = fala * amplituda
		cel_np = -fala * amplituda
		cel_rl = -fala * amplituda * 0.8
		cel_rp = fala * amplituda * 0.5

	if _faza_uderzenia >= 0.0:
		# ZAMACH Z BOKU: ręka idzie w prawo i do tyłu, potem tnie poziomo
		# w lewo przez przód; tułów skręca się razem z nią.
		_faza_uderzenia += delta / czas_uderzenia
		var t := _faza_uderzenia
		var rolka := 0.0     # uniesienie ręki w bok
		var obrot := 0.0     # obrót ręki w poziomie
		var skret := 0.0     # skręt tułowia
		if t < 0.45:
			var a := t / 0.45
			var e := a * a * (3.0 - 2.0 * a)
			rolka = 1.55 * e
			obrot = -1.4 * e
			skret = -0.55 * e
		elif t < 0.62:
			var b := (t - 0.45) / 0.17
			var e2 := b * b
			rolka = 1.55
			obrot = lerpf(-1.4, 1.7, e2)
			skret = lerpf(-0.55, 0.5, e2)
		else:
			var c := minf((t - 0.62) / 0.38, 1.0)
			var e3 := c * c * (3.0 - 2.0 * c)
			rolka = lerpf(1.55, 0.0, e3)
			obrot = lerpf(1.7, 0.0, e3)
			skret = lerpf(0.5, 0.0, e3)
		_reka_p.rotation = Vector3(0.0, obrot, rolka)
		_tulow.rotation.y = skret
		cel_rl = -0.5
		if t >= 0.6 and not _uderzenie_wyslane:
			_uderzenie_wyslane = true
			uderzenie.emit()
		if t >= 1.0:
			_faza_uderzenia = -1.0
	else:
		_reka_p.rotation = Vector3(
			lerp_angle(_reka_p.rotation.x, cel_rp, plynnosc),
			lerp_angle(_reka_p.rotation.y, 0.0, plynnosc),
			lerp_angle(_reka_p.rotation.z, 0.0, plynnosc))
		_tulow.rotation.y = lerp_angle(_tulow.rotation.y, 0.0, plynnosc)

	_noga_l.rotation.x = lerp_angle(_noga_l.rotation.x, cel_nl, plynnosc)
	_noga_p.rotation.x = lerp_angle(_noga_p.rotation.x, cel_np, plynnosc)
	_reka_l.rotation.x = lerp_angle(_reka_l.rotation.x, cel_rl, plynnosc)
	# delikatny oddech, gdy stoi
	_tulow.scale.y = 1.0 + 0.012 * sin(_czas * 2.2)
