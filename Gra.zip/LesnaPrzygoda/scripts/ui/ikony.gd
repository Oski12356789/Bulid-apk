extends RefCounted
## Proste ikony rysowane kodem (bez plików graficznych).
## Wywołujemy je z funkcji _draw() dowolnej kontrolki.

static func rysuj(c: CanvasItem, rodzaj: String, s: Vector2, r: float, kolor: Color = Color.WHITE) -> void:
	match rodzaj:
		"moneta": _moneta(c, s, r)
		"drzewo": _drzewo(c, s, r)
		"siekiera": _siekiera(c, s, r, kolor)
		"sklep": _sklep(c, s, r)
		"swiat": _swiat(c, s, r)
		"kamera": _kamera(c, s, r)
		"menu": _menu(c, s, r)

static func _moneta(c: CanvasItem, s: Vector2, r: float) -> void:
	c.draw_circle(s, r * 0.9, Color(0.72, 0.5, 0.05))
	c.draw_circle(s, r * 0.76, Color(1.0, 0.83, 0.22))
	c.draw_arc(s, r * 0.5, 0.0, TAU, 24, Color(0.78, 0.55, 0.08), r * 0.12)

static func _drzewo(c: CanvasItem, s: Vector2, r: float) -> void:
	c.draw_rect(Rect2(s.x - r * 0.12, s.y + r * 0.35, r * 0.24, r * 0.55), Color(0.45, 0.3, 0.15))
	for i in 3:
		var y := s.y - r * 0.55 + i * r * 0.38
		var w := r * (0.45 + i * 0.22)
		c.draw_colored_polygon(PackedVector2Array([
			Vector2(s.x, y - r * 0.4), Vector2(s.x + w, y + r * 0.3), Vector2(s.x - w, y + r * 0.3)]),
			Color(0.16, 0.55, 0.22))

static func _siekiera(c: CanvasItem, s: Vector2, r: float, kolor: Color) -> void:
	c.draw_line(s + Vector2(-r * 0.6, r * 0.85), s + Vector2(r * 0.35, -r * 0.7), Color(0.5, 0.33, 0.15), r * 0.2)
	c.draw_colored_polygon(PackedVector2Array([
		s + Vector2(r * 0.1, -r * 0.95), s + Vector2(r * 0.95, -r * 0.7),
		s + Vector2(r * 0.8, -r * 0.05), s + Vector2(r * 0.25, -r * 0.35)]), kolor)
	c.draw_polyline(PackedVector2Array([
		s + Vector2(r * 0.1, -r * 0.95), s + Vector2(r * 0.95, -r * 0.7),
		s + Vector2(r * 0.8, -r * 0.05), s + Vector2(r * 0.25, -r * 0.35),
		s + Vector2(r * 0.1, -r * 0.95)]), Color(0.1, 0.1, 0.1, 0.7), r * 0.06)

static func _sklep(c: CanvasItem, s: Vector2, r: float) -> void:
	# ściana i drzwi
	c.draw_rect(Rect2(s.x - r * 0.8, s.y - r * 0.1, r * 1.6, r * 0.95), Color(0.85, 0.7, 0.45))
	c.draw_rect(Rect2(s.x - r * 0.2, s.y + r * 0.25, r * 0.4, r * 0.6), Color(0.4, 0.25, 0.12))
	# daszek w paski
	for i in 4:
		var x0 := s.x - r * 0.95 + i * r * 0.475
		var kol := Color(0.85, 0.15, 0.12) if i % 2 == 0 else Color(0.97, 0.97, 0.95)
		c.draw_colored_polygon(PackedVector2Array([
			Vector2(x0 + r * 0.08, s.y - r * 0.85), Vector2(x0 + r * 0.55, s.y - r * 0.85),
			Vector2(x0 + r * 0.475, s.y - r * 0.1), Vector2(x0, s.y - r * 0.1)]), kol)

static func _swiat(c: CanvasItem, s: Vector2, r: float) -> void:
	c.draw_circle(s, r * 0.85, Color(0.2, 0.5, 0.85))
	c.draw_circle(s + Vector2(-r * 0.2, -r * 0.15), r * 0.35, Color(0.3, 0.7, 0.3))
	c.draw_circle(s + Vector2(r * 0.3, r * 0.3), r * 0.25, Color(0.3, 0.7, 0.3))
	c.draw_arc(s, r * 0.85, 0.0, TAU, 32, Color(1, 1, 1, 0.6), r * 0.07)

static func _kamera(c: CanvasItem, s: Vector2, r: float) -> void:
	c.draw_rect(Rect2(s.x - r * 0.85, s.y - r * 0.45, r * 1.7, r * 1.1), Color(0.85, 0.88, 0.92))
	c.draw_rect(Rect2(s.x - r * 0.35, s.y - r * 0.7, r * 0.7, r * 0.3), Color(0.85, 0.88, 0.92))
	c.draw_circle(s + Vector2(0, r * 0.1), r * 0.38, Color(0.15, 0.2, 0.3))
	c.draw_circle(s + Vector2(0, r * 0.1), r * 0.22, Color(0.4, 0.6, 0.9))

static func _menu(c: CanvasItem, s: Vector2, r: float) -> void:
	for i in 3:
		c.draw_rect(Rect2(s.x - r * 0.7, s.y - r * 0.6 + float(i) * r * 0.55, r * 1.4, r * 0.22), Color.WHITE)
