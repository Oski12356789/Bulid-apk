extends Control
## Menu gry: wznów, zapisz, czułość kamery i nowa gra.

signal zamkniety

var _status: Label
var _przycisk_nowa: Button
var _suwak: HSlider
var _etykieta_suwaka: Label
var _potwierdzenie := false

func _ready() -> void:
	visible = false
	mouse_filter = Control.MOUSE_FILTER_STOP
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var tlo := ColorRect.new()
	tlo.color = Color(0, 0, 0, 0.65)
	add_child(tlo)
	tlo.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var panel := PanelContainer.new()
	var styl := StyleBoxFlat.new()
	styl.bg_color = Color(0.16, 0.11, 0.07, 0.98)
	styl.set_corner_radius_all(18)
	panel.add_theme_stylebox_override("panel", styl)
	add_child(panel)
	panel.anchor_left = 0.25
	panel.anchor_right = 0.75
	panel.anchor_top = 0.06
	panel.anchor_bottom = 0.94
	panel.offset_left = 0.0
	panel.offset_right = 0.0
	panel.offset_top = 0.0
	panel.offset_bottom = 0.0

	var m := MarginContainer.new()
	for strona in ["margin_left", "margin_right", "margin_top", "margin_bottom"]:
		m.add_theme_constant_override(strona, 20)
	panel.add_child(m)
	var k := VBoxContainer.new()
	k.add_theme_constant_override("separation", 12)
	m.add_child(k)

	var tytul := Label.new()
	tytul.text = "MENU"
	tytul.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	tytul.add_theme_font_size_override("font_size", 40)
	k.add_child(tytul)

	k.add_child(_przycisk("WZNÓW GRĘ", zamknij_okno))
	k.add_child(_przycisk("ZAPISZ GRĘ", _zapisz_klik))

	_etykieta_suwaka = Label.new()
	_etykieta_suwaka.add_theme_font_size_override("font_size", 26)
	k.add_child(_etykieta_suwaka)
	_suwak = HSlider.new()
	_suwak.min_value = 0.8
	_suwak.max_value = 5.0
	_suwak.step = 0.1
	_suwak.custom_minimum_size = Vector2(0, 50)
	_suwak.value_changed.connect(_suwak_zmieniony)
	k.add_child(_suwak)

	_przycisk_nowa = _przycisk("NOWA GRA", _nowa_klik)
	k.add_child(_przycisk_nowa)

	_status = Label.new()
	_status.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_status.add_theme_font_size_override("font_size", 24)
	_status.add_theme_color_override("font_color", Color(0.6, 1.0, 0.6))
	k.add_child(_status)

func _przycisk(tekst: String, akcja: Callable) -> Button:
	var b := Button.new()
	b.text = tekst
	b.custom_minimum_size = Vector2(0, 68)
	b.add_theme_font_size_override("font_size", 30)
	b.pressed.connect(akcja)
	return b

func otworz() -> void:
	visible = true
	_potwierdzenie = false
	_przycisk_nowa.text = "NOWA GRA"
	_status.text = ""
	_suwak.set_value_no_signal(Stan.czulosc_kamery)
	_odswiez_etykiete()

func zamknij_okno() -> void:
	visible = false
	zamkniety.emit()

func _odswiez_etykiete() -> void:
	_etykieta_suwaka.text = "Czułość kamery: %.1f" % _suwak.value

func _suwak_zmieniony(wartosc: float) -> void:
	Stan.czulosc_kamery = wartosc
	_odswiez_etykiete()
	Stan.zmieniono.emit()

func _zapisz_klik() -> void:
	Stan.zapisz()
	_status.text = "Gra zapisana!"

## Nowa gra kasuje postęp, więc wymaga drugiego kliknięcia.
func _nowa_klik() -> void:
	if not _potwierdzenie:
		_potwierdzenie = true
		_przycisk_nowa.text = "NA PEWNO? KLIKNIJ JESZCZE RAZ"
		_status.text = "To skasuje cały postęp."
		return
	Stan.nowa_gra()
