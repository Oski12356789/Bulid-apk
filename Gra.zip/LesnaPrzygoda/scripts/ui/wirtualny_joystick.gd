extends Control
## Wirtualny joystick dotykowy. Obsługuje wiele palców naraz (multitouch).
## Odczyt: właściwość "wartosc" (Vector2, każda składowa od -1 do 1).

var wartosc := Vector2.ZERO
var promien := 110.0          ## jak daleko można wychylić gałkę (w pikselach)
var _indeks := -1             ## numer palca, który trzyma ten joystick
var _galka := Vector2.ZERO    ## przesunięcie gałki od środka

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _input(zdarzenie: InputEvent) -> void:
	if not is_visible_in_tree():
		return
	if zdarzenie is InputEventScreenTouch:
		if zdarzenie.pressed and _indeks == -1 \
				and get_global_rect().has_point(zdarzenie.position):
			_indeks = zdarzenie.index
			_aktualizuj(zdarzenie.position)
		elif not zdarzenie.pressed and zdarzenie.index == _indeks:
			_indeks = -1
			wartosc = Vector2.ZERO
			_galka = Vector2.ZERO
			queue_redraw()
	elif zdarzenie is InputEventScreenDrag and zdarzenie.index == _indeks:
		_aktualizuj(zdarzenie.position)

func resetuj() -> void:
	_indeks = -1
	wartosc = Vector2.ZERO
	_galka = Vector2.ZERO
	queue_redraw()

func _aktualizuj(pozycja: Vector2) -> void:
	var roznica := pozycja - get_global_rect().get_center()
	if roznica.length() > promien:
		roznica = roznica.normalized() * promien
	_galka = roznica
	# mała martwa strefa, żeby postać nie "pełzła" od drżenia palca
	if roznica.length() < promien * 0.12:
		wartosc = Vector2.ZERO
	else:
		wartosc = roznica / promien
	queue_redraw()

func _draw() -> void:
	var srodek := size * 0.5
	draw_circle(srodek, promien, Color(1, 1, 1, 0.10))
	draw_arc(srodek, promien, 0.0, TAU, 48, Color(1, 1, 1, 0.40), 3.0)
	draw_circle(srodek + _galka, promien * 0.42, Color(1, 1, 1, 0.45))
