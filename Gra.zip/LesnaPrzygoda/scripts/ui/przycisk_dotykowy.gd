extends Control
## Okrągły przycisk dotykowy (działa razem z joystickami, multitouch).

const Ikony := preload("res://scripts/ui/ikony.gd")

signal wcisniety
signal puszczony

var tekst := ""
var ikona := ""        ## jeśli niepusta, rysujemy ikonę nad tekstem
var promien := 70.0
var kolor := Color(0.2, 0.5, 0.2)
var _indeks := -1

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _input(zdarzenie: InputEvent) -> void:
	if not (zdarzenie is InputEventScreenTouch):
		return
	if not is_visible_in_tree():
		return
	var srodek := get_global_rect().get_center()
	if zdarzenie.pressed and _indeks == -1 \
			and (zdarzenie.position - srodek).length() <= promien * 1.15:
		_indeks = zdarzenie.index
		wcisniety.emit()
		queue_redraw()
	elif not zdarzenie.pressed and zdarzenie.index == _indeks:
		_indeks = -1
		puszczony.emit()
		queue_redraw()

func resetuj() -> void:
	if _indeks != -1:
		_indeks = -1
		puszczony.emit()
		queue_redraw()

func _draw() -> void:
	var srodek := size * 0.5
	var tlo := kolor
	tlo.a = 0.85 if _indeks != -1 else 0.55
	draw_circle(srodek, promien, tlo)
	draw_arc(srodek, promien, 0.0, TAU, 48, Color(1, 1, 1, 0.7), 3.0)
	var czcionka := ThemeDB.fallback_font
	if ikona != "" and tekst == "":
		Ikony.rysuj(self, ikona, srodek, promien * 0.62)
		return
	if ikona != "":
		Ikony.rysuj(self, ikona, srodek + Vector2(0, -promien * 0.18), promien * 0.5)
		var maly := int(promien * 0.26)
		var sz := czcionka.get_string_size(tekst, HORIZONTAL_ALIGNMENT_LEFT, -1, maly).x
		draw_string(czcionka, Vector2(srodek.x - sz * 0.5, srodek.y + promien * 0.72),
			tekst, HORIZONTAL_ALIGNMENT_LEFT, -1, maly, Color.WHITE)
		return
	var rozmiar_tekstu := int(promien * 0.34)
	var szerokosc := czcionka.get_string_size(tekst,
		HORIZONTAL_ALIGNMENT_LEFT, -1, rozmiar_tekstu).x
	draw_string(czcionka,
		Vector2(srodek.x - szerokosc * 0.5, srodek.y + rozmiar_tekstu * 0.35),
		tekst, HORIZONTAL_ALIGNMENT_LEFT, -1, rozmiar_tekstu, Color.WHITE)
