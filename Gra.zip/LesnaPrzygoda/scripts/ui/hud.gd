extends CanvasLayer
## Interfejs: joysticki, przyciski, liczniki na górze, sklep i menu.
## Przycisk EKWIPUNEK dodamy później, gdy będzie miał co pokazywać.

const Joystick := preload("res://scripts/ui/wirtualny_joystick.gd")
const Przycisk := preload("res://scripts/ui/przycisk_dotykowy.gd")
const Ikona := preload("res://scripts/ui/ikona_kontrolka.gd")
const SklepUI := preload("res://scripts/shop/sklep_ui.gd")
const MenuUI := preload("res://scripts/ui/menu_ui.gd")

var _gracz                      ## ustawiane przez polacz_z_graczem()
var _joy_ruch: Joystick
var _joy_kamera: Joystick
var _p_scinaj: Przycisk
var _p_skok: Przycisk
var _p_sklep: Przycisk
var _p_widok: Przycisk
var _p_menu: Przycisk
var _sterowanie: Array = []
var _sklep: Control
var _menu: Control
var _fps: Label
var _celownik: Label
var _rzad: HBoxContainer
var _l_pieniadze: Label
var _l_drzewa: Label
var _l_siekiera: Label

func _ready() -> void:
	layer = 10
	_joy_ruch = Joystick.new()
	_joy_kamera = Joystick.new()
	_p_scinaj = _nowy_przycisk("ŚCINAJ", "", Color(0.75, 0.35, 0.1))
	_p_skok = _nowy_przycisk("SKOK", "", Color(0.15, 0.45, 0.75))
	_p_sklep = _nowy_przycisk("", "sklep", Color(0.5, 0.3, 0.1))
	_p_widok = _nowy_przycisk("", "kamera", Color(0.2, 0.3, 0.45))
	_p_menu = _nowy_przycisk("", "menu", Color(0.25, 0.25, 0.3))
	_sterowanie = [_joy_ruch, _joy_kamera, _p_scinaj, _p_skok, _p_sklep, _p_widok, _p_menu]
	for element in _sterowanie:
		add_child(element)

	_zbuduj_liczniki()

	_fps = Label.new()
	_fps.position = Vector2(12, 8)
	_fps.add_theme_font_size_override("font_size", 20)
	add_child(_fps)

	_celownik = Label.new()
	_celownik.text = "+"
	_celownik.visible = false
	_celownik.add_theme_font_size_override("font_size", 44)
	_celownik.add_theme_color_override("font_color", Color(1, 1, 1, 0.85))
	_celownik.add_theme_color_override("font_outline_color", Color.BLACK)
	_celownik.add_theme_constant_override("outline_size", 6)
	add_child(_celownik)

	_sklep = SklepUI.new()
	add_child(_sklep)
	_sklep.zamkniety.connect(_po_zamknieciu_okna)
	_menu = MenuUI.new()
	add_child(_menu)
	_menu.zamkniety.connect(_po_zamknieciu_okna)

	_p_scinaj.wcisniety.connect(func(): if _gracz: _gracz.scinaj(true))
	_p_scinaj.puszczony.connect(func(): if _gracz: _gracz.scinaj(false))
	_p_skok.wcisniety.connect(func(): if _gracz: _gracz.skocz())
	_p_widok.wcisniety.connect(func(): if _gracz: _gracz.przelacz_widok())
	_p_sklep.wcisniety.connect(_otworz_sklep)
	_p_menu.wcisniety.connect(_otworz_menu)

	Stan.zmieniono.connect(_odswiez_liczniki)
	Stan.drzewo_sciete.connect(_pokaz_nagrode)
	get_viewport().size_changed.connect(_uloz)
	_uloz()
	_odswiez_liczniki()

func _nowy_przycisk(tekst: String, ikona: String, kolor: Color) -> Przycisk:
	var p := Przycisk.new()
	p.tekst = tekst
	p.ikona = ikona
	p.kolor = kolor
	return p

func polacz_z_graczem(gracz) -> void:
	_gracz = gracz
	_celownik.visible = gracz.pierwsza_osoba
	gracz.widok_zmieniony.connect(func(pierwsza: bool): _celownik.visible = pierwsza)

# ---------- liczniki: mały rząd na górze ekranu ----------

func _zbuduj_liczniki() -> void:
	_rzad = HBoxContainer.new()
	_rzad.add_theme_constant_override("separation", 14)
	add_child(_rzad)
	_rzad.anchor_left = 0.5
	_rzad.anchor_right = 0.5
	_rzad.anchor_top = 0.0
	_rzad.anchor_bottom = 0.0
	_rzad.offset_left = 0.0
	_rzad.offset_right = 0.0
	_rzad.offset_top = 8.0
	_rzad.grow_horizontal = Control.GROW_DIRECTION_BOTH
	_l_pieniadze = _licznik("moneta", Color(1, 0.9, 0.35))
	_l_drzewa = _licznik("drzewo", Color(0.75, 1, 0.75))
	_l_siekiera = _licznik("siekiera", Color.WHITE)

func _licznik(rodzaj: String, kolor_tekstu: Color) -> Label:
	var panel := PanelContainer.new()
	var styl := StyleBoxFlat.new()
	styl.bg_color = Color(0, 0, 0, 0.5)
	styl.set_corner_radius_all(14)
	styl.content_margin_left = 10.0
	styl.content_margin_right = 14.0
	styl.content_margin_top = 4.0
	styl.content_margin_bottom = 4.0
	panel.add_theme_stylebox_override("panel", styl)
	_rzad.add_child(panel)
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 8)
	panel.add_child(h)
	var ik := Ikona.new()
	ik.rodzaj = rodzaj
	ik.kolor = Color(0.8, 0.85, 0.9)
	ik.custom_minimum_size = Vector2(34, 34)
	h.add_child(ik)
	var l := Label.new()
	l.add_theme_font_size_override("font_size", 28)
	l.add_theme_color_override("font_color", kolor_tekstu)
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.add_theme_constant_override("outline_size", 5)
	h.add_child(l)
	return l

func _odswiez_liczniki() -> void:
	_l_pieniadze.text = str(Stan.pieniadze)
	_l_drzewa.text = str(Stan.sciete_drzewa)
	_l_siekiera.text = "%d/%d" % [Stan.aktualna_siekiera + 1, Stan.SIEKIERY.size()]

func _pokaz_nagrode(nagroda: int) -> void:
	var s := get_viewport().get_visible_rect().size
	var l := Label.new()
	l.text = "+%d" % nagroda
	l.add_theme_font_size_override("font_size", 40)
	l.add_theme_color_override("font_color", Color(1, 0.88, 0.3))
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.add_theme_constant_override("outline_size", 6)
	l.position = Vector2(s.x * 0.5 - 150, 62)
	add_child(l)
	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(l, "position:y", l.position.y + 36.0, 1.1)
	tw.tween_property(l, "modulate:a", 0.0, 1.1)
	tw.chain().tween_callback(l.queue_free)

# ---------- sklep i menu ----------

func _zablokuj_sterowanie(czy: bool) -> void:
	for k in _sterowanie:
		if czy:
			k.resetuj()
		k.visible = not czy
	if czy and _gracz:
		_gracz.ustaw_ruch(Vector2.ZERO)
		_gracz.ustaw_kamere(Vector2.ZERO)
		_gracz.scinaj(false)

func _okno_otwarte() -> bool:
	return _sklep.visible or _menu.visible

func _otworz_sklep() -> void:
	if _okno_otwarte():
		return
	_zablokuj_sterowanie(true)
	_sklep.otworz()

func _otworz_menu() -> void:
	if _okno_otwarte():
		return
	_zablokuj_sterowanie(true)
	_menu.otworz()

func _po_zamknieciu_okna() -> void:
	_zablokuj_sterowanie(false)

func _unhandled_input(zdarzenie: InputEvent) -> void:
	if zdarzenie is InputEventKey and zdarzenie.pressed and not zdarzenie.echo:
		if zdarzenie.keycode == KEY_B:
			if _sklep.visible:
				_sklep.zamknij_okno()
			else:
				_otworz_sklep()
		elif zdarzenie.keycode == KEY_ESCAPE:
			if _sklep.visible:
				_sklep.zamknij_okno()
			elif _menu.visible:
				_menu.zamknij_okno()
			else:
				_otworz_menu()

# ---------- układ elementów ----------

func _uloz() -> void:
	var s := get_viewport().get_visible_rect().size
	var u := s.y / 720.0     # skala względem ekranu 1280x720
	_ustaw(_joy_ruch, Vector2(200, s.y - 170 * u), 110 * u, 2.6)
	_ustaw(_joy_kamera, Vector2(s.x - 330 * u, s.y - 150 * u), 100 * u, 2.6)
	_ustaw(_p_scinaj, Vector2(s.x - 120 * u, s.y - 290 * u), 78 * u, 2.0)
	_ustaw(_p_skok, Vector2(s.x - 120 * u, s.y - 125 * u), 64 * u, 2.0)
	_ustaw(_p_menu, Vector2(s.x - 55, 55), 42.0, 2.0)
	_ustaw(_p_widok, Vector2(s.x - 155, 55), 42.0, 2.0)
	_ustaw(_p_sklep, Vector2(s.x - 255, 55), 42.0, 2.0)
	_celownik.position = s * 0.5 - Vector2(12, 28)

func _ustaw(element: Control, srodek: Vector2, promien: float, mnoznik: float) -> void:
	element.promien = promien
	element.size = Vector2.ONE * promien * mnoznik
	element.position = srodek - element.size * 0.5
	element.queue_redraw()

func _process(_delta: float) -> void:
	_fps.text = "FPS: %d" % Engine.get_frames_per_second()
	if _gracz and not _okno_otwarte():
		_gracz.ustaw_ruch(_joy_ruch.wartosc)
		_gracz.ustaw_kamere(_joy_kamera.wartosc)
