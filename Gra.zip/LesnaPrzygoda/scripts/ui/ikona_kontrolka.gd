extends Control
## Kontrolka, która pokazuje jedną ikonę z ikony.gd (moneta, drzewo, siekiera...).

const Ikony := preload("res://scripts/ui/ikony.gd")

var rodzaj := ""
var kolor := Color.WHITE

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _draw() -> void:
	Ikony.rysuj(self, rodzaj, size * 0.5, minf(size.x, size.y) * 0.5, kolor)
