extends Node3D
## Główna scena świata: teren, światło, niebo, mgła, las, gracz i interfejs.

const GraczSkrypt := preload("res://scripts/player/gracz.gd")
const HudSkrypt := preload("res://scripts/ui/hud.gd")
const LasSkrypt := preload("res://scripts/trees/las.gd")

var teren: Teren
var gracz: CharacterBody3D
var las: Node3D
var hud: CanvasLayer

func _ready() -> void:
	teren = Teren.new()
	teren.name = "Teren"
	add_child(teren)
	_dodaj_swiatlo()
	_dodaj_srodowisko()
	_dodaj_gracza()
	_dodaj_las()
	_dodaj_interfejs()

func _dodaj_swiatlo() -> void:
	var slonce := DirectionalLight3D.new()
	slonce.name = "Slonce"
	slonce.rotation_degrees = Vector3(-50, -35, 0)
	slonce.light_color = Color(1.0, 0.95, 0.85)
	slonce.shadow_enabled = true
	slonce.directional_shadow_max_distance = 120.0   # cienie tylko blisko = szybciej
	add_child(slonce)

func _dodaj_srodowisko() -> void:
	var niebo_mat := ProceduralSkyMaterial.new()
	niebo_mat.sky_top_color = Color(0.35, 0.55, 0.85)
	niebo_mat.sky_horizon_color = Color(0.7, 0.8, 0.9)
	niebo_mat.ground_horizon_color = Color(0.7, 0.8, 0.9)
	var niebo := Sky.new()
	niebo.sky_material = niebo_mat

	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	env.sky = niebo
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.fog_enabled = true
	env.fog_light_color = Color(0.7, 0.8, 0.9)
	env.fog_density = 0.005

	var swiat_env := WorldEnvironment.new()
	swiat_env.name = "Srodowisko"
	swiat_env.environment = env
	add_child(swiat_env)

func _dodaj_gracza() -> void:
	gracz = GraczSkrypt.new()
	gracz.name = "Gracz"
	var x := 0.0
	var z := 0.0
	if Stan.ma_pozycje:      # kontynuujemy tam, gdzie gracz skończył
		x = Stan.pozycja_gracza.x
		z = Stan.pozycja_gracza.z
	gracz.position = Vector3(x, teren.wysokosc_w(x, z) + 2.0, z)
	add_child(gracz)
	Stan.gracz = gracz

func _dodaj_las() -> void:
	las = LasSkrypt.new()
	las.name = "Las"
	las.teren = teren
	las.gracz = gracz
	add_child(las)
	gracz.las = las

func _dodaj_interfejs() -> void:
	hud = HudSkrypt.new()
	hud.name = "Hud"
	add_child(hud)
	hud.polacz_z_graczem(gracz)
