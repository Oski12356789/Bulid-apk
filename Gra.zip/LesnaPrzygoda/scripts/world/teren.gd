class_name Teren
extends Node3D
## Generuje nierówny, pagórkowaty teren z kolizją.
## Wysokość liczymy z szumu (FastNoiseLite), więc każdy punkt mapy ma swoją wysokość.

@export var rozmiar: float = 256.0      ## długość boku mapy w metrach
@export var podzialy: int = 128         ## na ile kwadratów dzielimy bok
@export var wysokosc: float = 14.0      ## maksymalna wysokość wzgórz
@export var ziarno: int = 12345         ## to samo ziarno = ten sam świat

var _szum_duzy := FastNoiseLite.new()
var _szum_maly := FastNoiseLite.new()
var _szum_kolor := FastNoiseLite.new()

func _ready() -> void:
	_przygotuj_szum()
	_zbuduj_teren()

func _przygotuj_szum() -> void:
	_szum_duzy.seed = ziarno
	_szum_duzy.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	_szum_duzy.frequency = 0.008        # duże wzgórza i doliny
	_szum_duzy.fractal_octaves = 3

	_szum_maly.seed = ziarno + 1
	_szum_maly.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	_szum_maly.frequency = 0.05         # małe nierówności
	_szum_maly.fractal_octaves = 2

	_szum_kolor.seed = ziarno + 2
	_szum_kolor.frequency = 0.03        # plamy różnych odcieni trawy

## Zwraca wysokość terenu w punkcie (x, z). Przyda się do sadzenia drzew.
func wysokosc_w(x: float, z: float) -> float:
	return _szum_duzy.get_noise_2d(x, z) * wysokosc \
		+ _szum_maly.get_noise_2d(x, z) * 1.5

func _normalna_w(x: float, z: float) -> Vector3:
	var e := 1.0
	var n := Vector3(
		wysokosc_w(x - e, z) - wysokosc_w(x + e, z),
		2.0 * e,
		wysokosc_w(x, z - e) - wysokosc_w(x, z + e))
	return n.normalized()

func _kolor_w(x: float, z: float, normalna: Vector3) -> Color:
	var plama := (_szum_kolor.get_noise_2d(x, z) + 1.0) * 0.5   # 0..1
	# kilka odcieni trawy, mieszanych plamami
	var trawa_jasna := Color(0.36, 0.52, 0.18)
	var trawa_ciemna := Color(0.18, 0.34, 0.12)
	var kolor := trawa_ciemna.lerp(trawa_jasna, plama)
	# w dolinach więcej ziemi i mchu
	var h := wysokosc_w(x, z)
	if h < -wysokosc * 0.3:
		kolor = kolor.lerp(Color(0.28, 0.22, 0.12), 0.55)
	# na stromych zboczach widać kamień i ziemię
	var stromosc := 1.0 - normalna.y
	if stromosc > 0.12:
		var t := clampf((stromosc - 0.12) * 4.0, 0.0, 1.0)
		kolor = kolor.lerp(Color(0.42, 0.37, 0.30), t)
	return kolor

func _zbuduj_teren() -> void:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var krok := rozmiar / float(podzialy)
	var start := -rozmiar * 0.5

	for i in podzialy:
		for j in podzialy:
			var x0 := start + i * krok
			var z0 := start + j * krok
			var x1 := x0 + krok
			var z1 := z0 + krok
			var a := _wierzcholek(x0, z0)
			var b := _wierzcholek(x1, z0)
			var c := _wierzcholek(x0, z1)
			var d := _wierzcholek(x1, z1)
			# dwa trójkąty tworzą jeden kwadrat (kolejność = strona widoczna)
			for w in [a, b, c, b, d, c]:
				st.set_normal(w.n)
				st.set_color(w.k)
				st.set_uv(w.u)
				st.add_vertex(w.p)

	var siatka := st.commit()
	var material := StandardMaterial3D.new()
	material.vertex_color_use_as_albedo = true
	material.roughness = 1.0
	# jasna tekstura detalu, mnożona przez kolory wierzchołków
	material.albedo_texture = load("res://textures/teren_detal.png")
	siatka.surface_set_material(0, material)

	var instancja := MeshInstance3D.new()
	instancja.name = "SiatkaTerenu"
	instancja.mesh = siatka
	add_child(instancja)

	# kolizja, żeby postać mogła po terenie chodzić
	var cialo := StaticBody3D.new()
	cialo.name = "KolizjaTerenu"
	var ksztalt := CollisionShape3D.new()
	ksztalt.shape = siatka.create_trimesh_shape()
	cialo.add_child(ksztalt)
	add_child(cialo)

func _wierzcholek(x: float, z: float) -> Dictionary:
	var n := _normalna_w(x, z)
	return {
		"p": Vector3(x, wysokosc_w(x, z), z),
		"n": n,
		"k": _kolor_w(x, z, n),
		"u": Vector2(x, z) / 6.0,   # co 6 metrów tekstura się powtarza
	}
