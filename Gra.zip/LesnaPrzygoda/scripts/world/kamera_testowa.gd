extends Camera3D
## Tymczasowa latająca kamera do oglądania świata na komputerze.
## Zniknie w ETAPIE 2, gdy dodamy postać gracza.
## Sterowanie: W/A/S/D = ruch, Q/E = dół/góra, Shift = szybciej,
## przytrzymaj prawy przycisk myszy i poruszaj myszą = rozglądanie.

var _predkosc := 15.0
var _czulosc := 0.003

func _unhandled_input(zdarzenie: InputEvent) -> void:
	if zdarzenie is InputEventMouseMotion \
			and Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT):
		rotation.y -= zdarzenie.relative.x * _czulosc
		rotation.x = clampf(rotation.x - zdarzenie.relative.y * _czulosc,
			-1.5, 1.5)

func _process(delta: float) -> void:
	var kierunek := Vector3.ZERO
	if Input.is_key_pressed(KEY_W): kierunek -= transform.basis.z
	if Input.is_key_pressed(KEY_S): kierunek += transform.basis.z
	if Input.is_key_pressed(KEY_A): kierunek -= transform.basis.x
	if Input.is_key_pressed(KEY_D): kierunek += transform.basis.x
	if Input.is_key_pressed(KEY_E): kierunek += Vector3.UP
	if Input.is_key_pressed(KEY_Q): kierunek -= Vector3.UP
	var mnoznik := 3.0 if Input.is_key_pressed(KEY_SHIFT) else 1.0
	position += kierunek.normalized() * _predkosc * mnoznik * delta
