extends StaticBody3D
## Jedno drzewo z kolizją. Wygląd stojącego drzewa rysuje MultiMesh (szybko),
## a ten węzeł pilnuje życia, nacięcia, wiórów, upadku, pieńka i odrastania.

const Def := preload("res://scripts/trees/definicje_drzew.gd")
const Gen := preload("res://scripts/trees/generator_drzew.gd")
const CZAS_ODROSTU := 90.0

enum Faza { STOI, PADA, LEZY }

var typ := "sosna"
var skala := 1.0
var hp_mnoznik := 1.0               ## wpływa na liczbę uderzeń, nie na wielkość
var kolor := Color.WHITE
var baza := Transform3D.IDENTITY     ## transform instancji w MultiMesh
var mm: MultiMesh
var indeks := 0
var siatki: Dictionary = {}
var las

var hp := 1.0
var hp_max := 1.0
var faza := Faza.STOI

var _def: Dictionary
var _kolizja: CollisionShape3D
var _ksztalt: CylinderShape3D
var _jasne: MeshInstance3D
var _szczelina: MeshInstance3D
var _kier_naciecia := Vector3.ZERO
var _pivot_pnia: Node3D
var _korona: MeshInstance3D
var _pieniek: Node3D
var _nac_pivot: Node3D
var _tw_drzenie: Tween

func _ready() -> void:
	_def = Def.TYPY[typ]
	hp_max = maxf(1.0, roundf(float(_def["hp"]) * hp_mnoznik))
	hp = hp_max
	_ksztalt = CylinderShape3D.new()
	_ksztalt.radius = promien_kolizji()
	_ksztalt.height = 5.0
	_kolizja = CollisionShape3D.new()
	_kolizja.shape = _ksztalt
	_kolizja.position.y = 2.5
	add_child(_kolizja)

func stoi() -> bool:
	return faza == Faza.STOI

func promien() -> float:
	return float(_def["promien"]) * skala

func promien_kolizji() -> float:
	return float(_def["kolizja"]) * skala

# ---------- uderzenie siekierą ----------

func trafienie(obrazenia: float, od: Vector3) -> void:
	if faza != Faza.STOI:
		return
	hp -= obrazenia
	var do_gracza := od - global_position
	do_gracza.y = 0.0
	do_gracza = do_gracza.normalized() if do_gracza.length() > 0.01 else Vector3.FORWARD
	_naciecie(do_gracza)
	_wiory(do_gracza)
	if hp <= 0.0:
		_sciete(-do_gracza)
	else:
		_drzenie(do_gracza, 1.0 - hp / hp_max)
		_liscie()

func _bryla(kolor_bryly: Color) -> MeshInstance3D:
	var mesh := BoxMesh.new()
	var mat := StandardMaterial3D.new()
	mat.albedo_color = kolor_bryly
	mat.roughness = 0.8
	mesh.material = mat
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	if _nac_pivot == null:
		_nac_pivot = Node3D.new()
		add_child(_nac_pivot)
	_nac_pivot.add_child(mi)
	return mi

## Jasne nacięcie na pniu rośnie z każdym uderzeniem.
func _naciecie(do_gracza: Vector3) -> void:
	if _jasne == null:
		_kier_naciecia = do_gracza
		_jasne = _bryla(Color(0.93, 0.78, 0.52))
		_szczelina = _bryla(Color(0.22, 0.13, 0.07))
	var frac := 1.0 - maxf(hp, 0.0) / hp_max
	var r := promien() * 0.97
	var w := r * 1.5
	var h := 0.15 + 0.5 * frac
	var d := 0.05 + r * 0.55 * frac
	var rot := Basis.looking_at(-_kier_naciecia, Vector3.UP)
	var poz := _kier_naciecia * (r - d * 0.5 + 0.03) + Vector3(0, 1.3, 0)
	_jasne.transform = Transform3D(rot.scaled_local(Vector3(w, h, d)), poz)
	_szczelina.transform = Transform3D(
		rot.scaled_local(Vector3(w * 0.85, 0.04 + 0.14 * frac, d + 0.02)),
		poz + Vector3(0, -h * 0.1, 0))

func _wiory(do_gracza: Vector3) -> void:
	var p := CPUParticles3D.new()
	var mesh := BoxMesh.new()
	mesh.size = Vector3(0.07, 0.04, 0.1)
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.93, 0.78, 0.52)
	mesh.material = mat
	p.mesh = mesh
	p.amount = 14
	p.lifetime = 0.8
	p.one_shot = true
	p.explosiveness = 1.0
	p.direction = do_gracza + Vector3(0, 0.6, 0)
	p.spread = 55.0
	p.initial_velocity_min = 1.5
	p.initial_velocity_max = 3.5
	p.gravity = Vector3(0, -9.0, 0)
	p.scale_amount_min = 0.6
	p.scale_amount_max = 1.5
	add_child(p)
	p.global_position = global_position + do_gracza * promien() + Vector3(0, 1.3, 0)
	p.emitting = true
	get_tree().create_timer(1.5).timeout.connect(p.queue_free)

## Drzewo drży po każdym uderzeniu: wahnięcie wokół podstawy, które wygasa.
func _drzenie(do_gracza: Vector3, frac: float) -> void:
	if _tw_drzenie and _tw_drzenie.is_valid():
		_tw_drzenie.kill()
	var os := Vector3.UP.cross(do_gracza).normalized()
	var amp := 0.035 + 0.05 * frac       # im bliżej ścięcia, tym mocniej się trzęsie
	_tw_drzenie = create_tween()
	_tw_drzenie.tween_method(_ustaw_drzenie.bind(os, amp), 0.0, 1.0, 0.7)

func _ustaw_drzenie(p: float, os: Vector3, amp: float) -> void:
	var kat := amp * (1.0 - p) * sin(p * 28.0)
	var b := Basis(os, kat)
	mm.set_instance_transform(indeks, Transform3D(b * baza.basis, baza.origin))
	if _nac_pivot:
		_nac_pivot.basis = b

## Kilka liści lub igieł spada z korony po uderzeniu.
func _liscie() -> void:
	var p := CPUParticles3D.new()
	var mesh := BoxMesh.new()
	mesh.size = Vector3(0.16, 0.03, 0.11)
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.3, 0.55, 0.18) * (_def["lisc"] as Color)
	mesh.material = mat
	p.mesh = mesh
	p.amount = 8
	p.lifetime = 2.2
	p.one_shot = true
	p.explosiveness = 0.9
	p.direction = Vector3.DOWN
	p.spread = 60.0
	p.initial_velocity_min = 0.2
	p.initial_velocity_max = 1.0
	p.gravity = Vector3(0, -2.5, 0)
	p.emission_shape = CPUParticles3D.EMISSION_SHAPE_SPHERE
	p.emission_sphere_radius = 1.6 * skala
	add_child(p)
	p.global_position = global_position + Vector3(0, float(_def["wysokosc"]) * skala * 0.72, 0)
	p.emitting = true
	get_tree().create_timer(2.8).timeout.connect(p.queue_free)

# ---------- ścięcie i upadek ----------

func _kopia(mat: StandardMaterial3D) -> StandardMaterial3D:
	mat.albedo_color = mat.albedo_color * kolor
	return mat

func _sciete(kier_upadku: Vector3) -> void:
	faza = Faza.PADA
	Stan.zarejestruj_sciecie(int(_def["nagroda"]))
	if _tw_drzenie and _tw_drzenie.is_valid():
		_tw_drzenie.kill()
	if _nac_pivot:
		_nac_pivot.queue_free()
		_nac_pivot = null
	_jasne = null
	_szczelina = null
	# stojące drzewo znika z MultiMesh, a zostaje pieniek z korzeniami
	mm.set_instance_transform(indeks, Transform3D(Basis.from_scale(Vector3.ONE * 0.0001), baza.origin))
	_zbuduj_pieniek()
	_zbuduj_pien_wizual()
	_ksztalt.height = 0.5
	_kolizja.position.y = 0.25
	var os := Vector3.UP.cross(kier_upadku).normalized()
	var wys := float(_def["wysokosc"]) * skala
	var tw := create_tween()
	tw.tween_method(_kat_upadku.bind(os), 0.0, 1.0, 1.7 + wys * 0.1) \
		.set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	tw.tween_callback(_wylozyl)

func _zbuduj_pien_wizual() -> void:
	_pivot_pnia = Node3D.new()
	add_child(_pivot_pnia)
	var pien := MeshInstance3D.new()
	pien.mesh = siatki["pien"]
	pien.transform = Transform3D(baza.basis, Vector3.ZERO)
	pien.set_surface_override_material(0, _kopia(Gen.material_kory(typ)))
	_pivot_pnia.add_child(pien)
	_korona = MeshInstance3D.new()
	_korona.mesh = siatki["korona"]
	_korona.transform = Transform3D(baza.basis, Vector3.ZERO)
	_korona.set_surface_override_material(0, _kopia(Gen.material_lisci(typ)))
	_pivot_pnia.add_child(_korona)

func _zbuduj_pieniek() -> void:
	_pieniek = Node3D.new()
	add_child(_pieniek)
	var mk := _kopia(Gen.material_kory(typ))
	var korzenie := MeshInstance3D.new()
	korzenie.mesh = siatki["korzenie"]
	korzenie.transform = Transform3D(baza.basis, Vector3.ZERO)
	korzenie.set_surface_override_material(0, mk)
	_pieniek.add_child(korzenie)
	var r := promien_kolizji() * 0.9
	var walec := CylinderMesh.new()
	walec.bottom_radius = r
	walec.top_radius = r * 0.95
	walec.height = 0.5
	walec.radial_segments = 10
	walec.rings = 1
	walec.cap_top = false
	walec.cap_bottom = false
	var w := MeshInstance3D.new()
	w.mesh = walec
	w.position.y = 0.25
	w.material_override = mk
	_pieniek.add_child(w)
	# jasny, przecięty wierzch pieńka ze słojami
	var wierzch := CylinderMesh.new()
	wierzch.bottom_radius = r * 0.95
	wierzch.top_radius = r * 0.95
	wierzch.height = 0.02
	wierzch.radial_segments = 10
	wierzch.rings = 1
	var mat_w := StandardMaterial3D.new()
	mat_w.albedo_texture = load("res://textures/drewno.png") as Texture2D
	wierzch.material = mat_w
	var wz := MeshInstance3D.new()
	wz.mesh = wierzch
	wz.position.y = 0.5
	_pieniek.add_child(wz)

func _kat_upadku(t: float, os: Vector3) -> void:
	if _pivot_pnia == null:
		return
	_pivot_pnia.basis = Basis(os, deg_to_rad(90.0) * t)
	_pivot_pnia.position.y = promien_kolizji() * 0.85 * t

func _wylozyl() -> void:
	faza = Faza.LEZY
	if las:
		las.zarejestruj_pien(self)
	var tw := create_tween()
	tw.tween_interval(6.0)
	tw.tween_callback(_zniknij_korona)
	get_tree().create_timer(CZAS_ODROSTU).timeout.connect(_odrosnij)

func _zniknij_korona() -> void:
	if not is_instance_valid(_korona):
		return
	var mat := _korona.get_surface_override_material(0) as StandardMaterial3D
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	var tw := create_tween()
	tw.tween_property(mat, "albedo_color:a", 0.0, 1.5)
	tw.tween_callback(func():
		if is_instance_valid(_korona):
			_korona.queue_free())

func usun_pien() -> void:
	if is_instance_valid(_pivot_pnia):
		_pivot_pnia.queue_free()
	_pivot_pnia = null
	_korona = null

# ---------- odrastanie ----------

func _odrosnij() -> void:
	if faza != Faza.LEZY:
		return
	usun_pien()
	if is_instance_valid(_pieniek):
		_pieniek.queue_free()
	_pieniek = null
	if las:
		las.usun_z_pni(self)
	faza = Faza.STOI
	hp = hp_max
	_ksztalt.height = 5.0
	_kolizja.position.y = 2.5
	create_tween().tween_method(_rosnij, 0.05, 1.0, 6.0)

func _rosnij(f: float) -> void:
	mm.set_instance_transform(indeks,
		Transform3D(baza.basis * Basis.from_scale(Vector3.ONE * f), baza.origin))
