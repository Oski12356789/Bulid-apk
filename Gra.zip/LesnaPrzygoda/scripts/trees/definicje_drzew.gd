extends RefCounted
## Dane pięciu gatunków drzew: życie, nagroda, wymiary i kolory.

const KOLEJNOSC: Array = ["sosna", "swierk", "brzoza", "buk", "dab"]

const TYPY: Dictionary = {
	"sosna": {"nazwa": "Sosna", "hp": 5.0, "nagroda": 10, "promien": 0.28, "kolizja": 0.36, "wysokosc": 10.5,
		"kora": "kora.png", "kora_kolor": Color(1.0, 0.82, 0.68), "lisc": Color(0.75, 1.0, 0.85)},
	"swierk": {"nazwa": "Świerk", "hp": 6.0, "nagroda": 12, "promien": 0.25, "kolizja": 0.34, "wysokosc": 10.7,
		"kora": "kora.png", "kora_kolor": Color(0.8, 0.66, 0.56), "lisc": Color(0.55, 0.85, 0.65)},
	"brzoza": {"nazwa": "Brzoza", "hp": 7.0, "nagroda": 15, "promien": 0.18, "kolizja": 0.26, "wysokosc": 8.6,
		"kora": "kora_brzoza.png", "kora_kolor": Color(1.0, 1.0, 1.0), "lisc": Color(1.0, 1.0, 0.6)},
	"buk": {"nazwa": "Buk", "hp": 9.0, "nagroda": 20, "promien": 0.40, "kolizja": 0.48, "wysokosc": 10.2,
		"kora": "kora_buk.png", "kora_kolor": Color(1.0, 1.0, 1.0), "lisc": Color(0.9, 1.0, 0.6)},
	"dab": {"nazwa": "Dąb", "hp": 12.0, "nagroda": 25, "promien": 0.58, "kolizja": 0.66, "wysokosc": 9.2,
		"kora": "kora.png", "kora_kolor": Color(0.85, 0.74, 0.64), "lisc": Color(0.8, 1.0, 0.5)},
}
