extends RefCounted
## Buduje siatki 3D drzew z prostych brył: pień, korzenie, gałęzie, korona.
## Każde drzewo składa się z trzech części (osobnych powierzchni):
## pień z gałęziami, korzenie i korona (liście lub igły).

const Def := preload("res://scripts/trees/definicje_drzew.gd")

static func material_kory(typ: String) -> StandardMaterial3D:
	var def: Dictionary = Def.TYPY[typ]
	var m := StandardMaterial3D.new()
	m.albedo_texture = load("res://textures/" + String(def["kora"])) as Texture2D
	m.albedo_color = def["kora_kolor"]
	m.uv1_scale = Vector3(2.0, 3.0, 1.0)
	m.roughness = 1.0
	m.vertex_color_use_as_albedo = true
	return m

static func material_lisci(typ: String) -> StandardMaterial3D:
	var def: Dictionary = Def.TYPY[typ]
	var m := StandardMaterial3D.new()
	m.albedo_texture = load("res://textures/liscie.png") as Texture2D
	m.albedo_color = def["lisc"]
	m.uv1_scale = Vector3(3.0, 3.0, 1.0)
	m.roughness = 1.0
	m.vertex_color_use_as_albedo = true
	return m

## Zwraca słownik z siatkami: pelny, pien, korzenie, korona.
static func zbuduj(typ: String) -> Dictionary:
	var mk := material_kory(typ)
	var ml := material_lisci(typ)
	var a := _czesci(typ)
	var pelny: ArrayMesh = a[0].commit()
	a[1].commit(pelny)
	a[2].commit(pelny)
	pelny.surface_set_material(0, mk)
	pelny.surface_set_material(1, mk)
	pelny.surface_set_material(2, ml)
	var b := _czesci(typ)
	var pien: ArrayMesh = b[0].commit()
	pien.surface_set_material(0, mk)
	var korzenie: ArrayMesh = b[1].commit()
	korzenie.surface_set_material(0, mk)
	var korona: ArrayMesh = b[2].commit()
	korona.surface_set_material(0, ml)
	return {"pelny": pelny, "pien": pien, "korzenie": korzenie, "korona": korona}

static func _czesci(typ: String) -> Array:
	var p := SurfaceTool.new()
	p.begin(Mesh.PRIMITIVE_TRIANGLES)
	var k := SurfaceTool.new()
	k.begin(Mesh.PRIMITIVE_TRIANGLES)
	var l := SurfaceTool.new()
	l.begin(Mesh.PRIMITIVE_TRIANGLES)
	match typ:
		"sosna": _sosna(p, k, l)
		"swierk": _swierk(p, k, l)
		"brzoza": _brzoza(p, k, l)
		"buk": _buk(p, k, l)
		"dab": _dab(p, k, l)
	return [p, k, l]

# ---------- elementy składowe ----------

static func _cyl(st: SurfaceTool, r_dol: float, r_gora: float, h: float, poz: Vector3,
		baza: Basis = Basis.IDENTITY, seg: int = 8) -> void:
	var m := CylinderMesh.new()
	m.bottom_radius = r_dol
	m.top_radius = r_gora
	m.height = h
	m.radial_segments = seg
	m.rings = 1
	st.append_from(m, 0, Transform3D(baza, poz))

static func _kula(st: SurfaceTool, poz: Vector3, skala: Vector3) -> void:
	var m := SphereMesh.new()
	m.radius = 1.0
	m.height = 2.0
	m.radial_segments = 9
	m.rings = 5
	st.append_from(m, 0, Transform3D(Basis.from_scale(skala), poz))

## Korzeń wychodzi z podstawy pnia na zewnątrz i lekko w dół, w ziemię.
static func _korzen(st: SurfaceTool, kat: float, r_pnia: float, dl: float, gr: float) -> void:
	var kier := Vector3(cos(kat), 0.0, sin(kat))
	var os := Vector3.UP.cross(kier).normalized()
	var baza := Basis(os, deg_to_rad(110.0))
	var osie := baza * Vector3.UP
	var start := kier * r_pnia * 0.6 + Vector3(0, 0.45, 0)
	_cyl(st, gr, gr * 0.15, dl, start + osie * dl * 0.5, baza, 6)

## Gałąź odchodząca od pnia w górę i na zewnątrz.
static func _galaz(st: SurfaceTool, kat: float, wys: float, dl: float, gr: float,
		odchylenie: float, r0: float) -> void:
	var kier := Vector3(cos(kat), 0.0, sin(kat))
	var os := Vector3.UP.cross(kier).normalized()
	var baza := Basis(os, deg_to_rad(odchylenie))
	var osie := baza * Vector3.UP
	var start := kier * r0 + Vector3(0, wys, 0)
	_cyl(st, gr, gr * 0.35, dl, start + osie * dl * 0.5, baza, 6)

static func _korzenie(st: SurfaceTool, ile: int, r_pnia: float, dl: float, gr: float) -> void:
	for i in ile:
		_korzen(st, TAU * float(i) / float(ile) + 0.4, r_pnia, dl, gr)

# ---------- gatunki ----------

static func _sosna(p: SurfaceTool, k: SurfaceTool, l: SurfaceTool) -> void:
	_cyl(p, 0.32, 0.15, 9.0, Vector3(0, 4.5, 0))
	_korzenie(k, 5, 0.3, 1.3, 0.16)
	_galaz(p, 0.5, 6.4, 1.3, 0.06, 55.0, 0.14)
	_galaz(p, 3.6, 7.2, 1.2, 0.05, 55.0, 0.13)
	_kula(l, Vector3(0, 8.0, 0), Vector3(2.0, 0.95, 2.0))
	_kula(l, Vector3(0.6, 9.0, 0.3), Vector3(1.6, 0.85, 1.6))
	_kula(l, Vector3(-0.4, 9.9, -0.3), Vector3(1.2, 0.8, 1.2))
	_kula(l, Vector3(-1.0, 7.0, 0.6), Vector3(1.5, 0.7, 1.5))
	_kula(l, Vector3(1.1, 7.2, -0.7), Vector3(1.3, 0.7, 1.3))

static func _swierk(p: SurfaceTool, k: SurfaceTool, l: SurfaceTool) -> void:
	_cyl(p, 0.3, 0.07, 10.5, Vector3(0, 5.25, 0))
	_korzenie(k, 4, 0.28, 1.1, 0.14)
	for i in 7:
		var y := 1.6 + float(i) * 1.25
		var r := 2.6 - float(i) * 0.36
		var h := 2.7 - float(i) * 0.18
		_cyl(l, r, 0.02, h, Vector3(0, y + h * 0.5, 0), Basis.IDENTITY, 9)

static func _brzoza(p: SurfaceTool, k: SurfaceTool, l: SurfaceTool) -> void:
	_cyl(p, 0.2, 0.08, 7.8, Vector3(0, 3.9, 0))
	_korzenie(k, 4, 0.2, 0.9, 0.1)
	_galaz(p, 0.8, 4.6, 1.5, 0.05, 50.0, 0.12)
	_galaz(p, 2.9, 5.2, 1.5, 0.05, 50.0, 0.11)
	_galaz(p, 5.0, 5.8, 1.4, 0.04, 50.0, 0.1)
	_kula(l, Vector3(0, 6.4, 0), Vector3(1.4, 1.7, 1.4))
	_kula(l, Vector3(0.8, 5.4, 0.4), Vector3(1.1, 1.2, 1.1))
	_kula(l, Vector3(-0.9, 5.8, -0.3), Vector3(1.1, 1.3, 1.1))
	_kula(l, Vector3(0.1, 7.6, 0), Vector3(0.9, 1.0, 0.9))

static func _buk(p: SurfaceTool, k: SurfaceTool, l: SurfaceTool) -> void:
	_cyl(p, 0.44, 0.26, 6.8, Vector3(0, 3.4, 0), Basis.IDENTITY, 10)
	_korzenie(k, 5, 0.42, 1.5, 0.22)
	_galaz(p, 1.0, 5.4, 2.0, 0.14, 45.0, 0.24)
	_galaz(p, 4.0, 5.8, 2.0, 0.14, 45.0, 0.24)
	_kula(l, Vector3(0, 7.6, 0), Vector3(2.3, 2.5, 2.3))
	_kula(l, Vector3(1.3, 6.6, 0.7), Vector3(1.7, 1.8, 1.7))
	_kula(l, Vector3(-1.2, 6.9, -0.8), Vector3(1.7, 1.8, 1.7))
	_kula(l, Vector3(0.2, 9.0, 0.2), Vector3(1.4, 1.3, 1.4))

static func _dab(p: SurfaceTool, k: SurfaceTool, l: SurfaceTool) -> void:
	_cyl(p, 0.62, 0.38, 4.2, Vector3(0, 2.1, 0), Basis.IDENTITY, 10)
	_korzenie(k, 6, 0.6, 1.7, 0.26)
	for i in 4:
		_galaz(p, TAU * float(i) / 4.0 + 0.3, 3.4, 2.8, 0.2, 48.0, 0.3)
	_kula(l, Vector3(0, 6.4, 0), Vector3(2.9, 2.1, 2.9))
	_kula(l, Vector3(2.4, 5.6, 0.9), Vector3(1.9, 1.5, 1.9))
	_kula(l, Vector3(-2.2, 5.8, -1.0), Vector3(1.9, 1.5, 1.9))
	_kula(l, Vector3(0.6, 5.5, -2.3), Vector3(1.8, 1.4, 1.8))
	_kula(l, Vector3(-0.7, 5.7, 2.2), Vector3(1.8, 1.4, 1.8))
	_kula(l, Vector3(0, 8.0, 0), Vector3(1.8, 1.2, 1.8))
