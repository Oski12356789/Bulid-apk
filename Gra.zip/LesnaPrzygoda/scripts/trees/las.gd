extends Node3D
## Rozsadza las: losowo, w naturalnych kępach gatunków, bez równych rzędów.
## Wygląd drzew jednego gatunku rysuje jeden MultiMesh (mało wywołań rysowania).

const Def := preload("res://scripts/trees/definicje_drzew.gd")
const Gen := preload("res://scripts/trees/generator_drzew.gd")
const DrzewoSkrypt := preload("res://scripts/trees/drzewo.gd")
const MAKS_PNI := 14

@export var liczba_drzew := 170
@export var rozmiar_drzew := 1.6      ## mnożnik wielkości wszystkich drzew
@export var polowa_mapy := 118.0

var teren          ## ustawiane przez świat przed dodaniem do sceny
var gracz
var _drzewa: Array = []
var _pnie: Array = []

func _ready() -> void:
	_generuj()
	if gracz:
		gracz.uderzenie.connect(_na_uderzenie)

func _generuj() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 20260101
	var szum := FastNoiseLite.new()
	szum.seed = 42
	szum.frequency = 0.012
	var meshe: Dictionary = {}
	var wpisy: Dictionary = {}
	for typ in Def.KOLEJNOSC:
		meshe[typ] = Gen.zbuduj(typ)
		wpisy[typ] = []
	var zajete: Array = []
	var proby := 0
	var ile := 0
	while ile < liczba_drzew and proby < liczba_drzew * 12:
		proby += 1
		var x := rng.randf_range(-polowa_mapy, polowa_mapy)
		var z := rng.randf_range(-polowa_mapy, polowa_mapy)
		var p := Vector2(x, z)
		if p.length() < 8.0:
			continue          # wolne miejsce na start gracza
		var za_blisko := false
		for q in zajete:
			if p.distance_squared_to(q) < 36.0:
				za_blisko = true
				break
		if za_blisko:
			continue
		var n := szum.get_noise_2d(x, z)
		var typ: String
		if rng.randf() < 0.25:
			typ = Def.KOLEJNOSC[rng.randi() % Def.KOLEJNOSC.size()]
		elif n < -0.30:
			typ = "sosna"
		elif n < -0.05:
			typ = "swierk"
		elif n < 0.15:
			typ = "brzoza"
		elif n < 0.35:
			typ = "buk"
		else:
			typ = "dab"
		zajete.append(p)
		ile += 1
		var los := rng.randf_range(0.85, 1.3)
		var lista: Array = wpisy[typ]
		lista.append({
			"poz": Vector3(x, teren.wysokosc_w(x, z) - 0.05, z),
			"los": los,
			"skala": los * rozmiar_drzew,
			"yaw": rng.randf() * TAU,
			"kolor": Color(rng.randf_range(0.85, 1.05), rng.randf_range(0.85, 1.05), rng.randf_range(0.85, 1.0)),
		})

	for typ in Def.KOLEJNOSC:
		var lista: Array = wpisy[typ]
		if lista.is_empty():
			continue
		var mm := MultiMesh.new()
		mm.transform_format = MultiMesh.TRANSFORM_3D
		mm.use_colors = true
		mm.mesh = meshe[typ]["pelny"]
		mm.instance_count = lista.size()
		var mmi := MultiMeshInstance3D.new()
		mmi.name = "Drzewa_" + typ
		mmi.multimesh = mm
		add_child(mmi)
		for i in lista.size():
			var w: Dictionary = lista[i]
			var sk: float = w["skala"]
			var poz: Vector3 = w["poz"]
			var kol: Color = w["kolor"]
			var t := Transform3D(Basis(Vector3.UP, float(w["yaw"])).scaled(Vector3.ONE * sk), poz)
			mm.set_instance_transform(i, t)
			mm.set_instance_color(i, kol)
			var d = DrzewoSkrypt.new()
			d.typ = typ
			d.skala = sk
			d.hp_mnoznik = float(w["los"])
			d.kolor = kol
			d.baza = t
			d.mm = mm
			d.indeks = i
			d.siatki = meshe[typ]
			d.las = self
			d.position = poz
			add_child(d)
			_drzewa.append(d)

## Najbliższe stojące drzewo; odległość liczymy od krawędzi pnia.
func najblizsze_drzewo(poz: Vector3, zasieg: float, kier: Vector3 = Vector3.ZERO):
	var najlepsze = null
	var najlepszy := 1000000.0
	for d in _drzewa:
		if not d.stoi():
			continue
		var do_pnia := Vector2(d.global_position.x - poz.x, d.global_position.z - poz.z)
		if kier != Vector3.ZERO and do_pnia.length() > 0.01:
			# tylko drzewa mniej więcej przed nami
			if Vector2(kier.x, kier.z).normalized().dot(do_pnia.normalized()) < 0.4:
				continue
		var odl: float = do_pnia.length() - d.promien_kolizji()
		if odl <= zasieg and odl < najlepszy:
			najlepszy = odl
			najlepsze = d
	return najlepsze

func _na_uderzenie() -> void:
	var kier := Vector3.ZERO
	if gracz.pierwsza_osoba:
		kier = gracz.kierunek_patrzenia()
	var d = najblizsze_drzewo(gracz.global_position, 2.0, kier)
	if d:
		d.trafienie(Stan.obrazenia(), gracz.global_position)

## Na ziemi zostaje najwyżej MAKS_PNI ściętych pni, najstarsze znikają.
func zarejestruj_pien(d) -> void:
	_pnie.append(d)
	if _pnie.size() > MAKS_PNI:
		var stary = _pnie.pop_front()
		stary.usun_pien()

func usun_z_pni(d) -> void:
	_pnie.erase(d)
