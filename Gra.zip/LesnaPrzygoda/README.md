# Leśna Przygoda 3D

Gra 3D w Godot 4 na Androida.

## Stan projektu
- ETAP 1-2: teren, tekstury, gracz, kamera, joysticki
- ETAP 3-4: 5 gatunków drzew z kolizją, ścinanie, sklep (10 siekier, 2 światy do kupienia)
- Widok z pierwszej osoby (przycisk z ikoną aparatu lub klawisz V)
- Zapis gry: pieniądze, drzewa, siekiery, światy, ustawienia i pozycja gracza (user://zapis.json)
- Menu (ikona z trzema kreskami lub Esc): wznów, zapisz, czułość kamery, nowa gra
- Wszystko napisane, ale NIEURUCHOMIONE przez autora kodu. Błędy zgłaszaj.

## Sterowanie na komputerze
- W/A/S/D ruch, Shift bieg, Spacja skok, F zamach siekierą, V zmiana widoku
- Strzałki lub prawy przycisk myszy: kamera
- B: sklep, Esc: menu, M: +1000 monet (tylko do testów)

## Zapis
Gra zapisuje się sama po każdej zmianie oraz przy wyjściu z gry. Ścięte drzewa odrastają
po ponownym uruchomieniu (zapamiętujemy postęp gracza, nie stan lasu).
